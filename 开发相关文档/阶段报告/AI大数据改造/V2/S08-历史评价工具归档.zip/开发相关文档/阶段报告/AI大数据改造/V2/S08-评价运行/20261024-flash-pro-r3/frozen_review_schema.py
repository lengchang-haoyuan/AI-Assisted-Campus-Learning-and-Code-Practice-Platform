"""practice-review/1.0输出校验快照：仅用于S08历史重放，不依赖当前生产提示词。"""

import re
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

SENSITIVE_TEXT_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~-]{16,}", re.IGNORECASE),
    re.compile(
        r"\b(?:api[_-]?key|password|secret|token)\b\s*[:=]\s*[\"']?"
        r"[A-Za-z0-9+/_.-]{16,}",
        re.IGNORECASE,
    ),
)

def validate_safe_text(value: str) -> str:
    normalized = value.strip()
    if any(pattern.search(normalized) for pattern in SENSITIVE_TEXT_PATTERNS):
        raise ValueError("Agent 输入或输出不能包含疑似密钥、密码或认证令牌")
    return normalized

def _validate_nested_text(value: object) -> None:
    if isinstance(value, str):
        validate_safe_text(value)
    elif isinstance(value, dict):
        for child in value.values():
            _validate_nested_text(child)
    elif isinstance(value, list):
        for child in value:
            _validate_nested_text(child)

class AgentSchema(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    @model_validator(mode="after")
    def reject_sensitive_text(self) -> "AgentSchema":
        _validate_nested_text(self.model_dump(mode="python"))
        return self

CriterionId = Literal["C01", "C02", "C03", "C04", "C05", "C06"]
IssueType = Literal[
    "missing_header_validation",
    "row_validation",
    "csv_quoting",
    "counting",
    "zero_as_missing",
    "unknown_as_known",
    "sum_error",
    "empty_result_contract",
    "external_io",
]


_CRITERION_ISSUES = {key: frozenset(values) for key, values in {'C01': ['missing_header_validation'], 'C02': ['csv_quoting', 'row_validation'], 'C03': ['counting', 'unknown_as_known', 'zero_as_missing'], 'C04': ['sum_error'], 'C05': ['empty_result_contract'], 'C06': ['external_io']}.items()}

class PracticeCriterionReview(AgentSchema):
    criterion_id: CriterionId
    verdict: Literal["pass", "fail", "unknown"]
    issue_type: IssueType | None = None
    evidence_span: str | None = Field(default=None, min_length=1, max_length=1500)
    reason: str = Field(min_length=1, max_length=500)
    suggested_self_test: str | None = Field(default=None, min_length=1, max_length=1000)
    next_action: str | None = Field(default=None, min_length=1, max_length=1000)

    @field_validator("reason", "suggested_self_test", "next_action", mode="before")
    @classmethod
    def normalize_text(cls, value: object) -> object:
        return validate_safe_text(value) if isinstance(value, str) else value

    @model_validator(mode="after")
    def verify_verdict(self):
        if self.evidence_span is not None and not self.evidence_span.strip():
            raise ValueError("代码引用不能只有空白")
        if self.verdict == "fail":
            if self.issue_type not in _CRITERION_ISSUES[self.criterion_id]:
                raise ValueError("问题类型必须对应当前验收项")
            if not self.evidence_span or not self.next_action or not self.suggested_self_test:
                raise ValueError("fail必须有代码依据、建议自测和下一动作")
        elif self.issue_type is not None:
            raise ValueError("非fail验收项不能登记确定问题类型")
        if self.verdict == "unknown" and not self.next_action:
            raise ValueError("unknown必须请求补齐缺少的材料")
        return self

class PracticeReviewDraft(AgentSchema):
    summary: str = Field(min_length=1, max_length=1000)
    overall: Literal["pass", "needs_changes", "insufficient"]
    criteria: list[PracticeCriterionReview] = Field(min_length=6, max_length=6)

    @field_validator("summary", mode="before")
    @classmethod
    def normalize_summary(cls, value: object) -> object:
        return validate_safe_text(value) if isinstance(value, str) else value

    @model_validator(mode="after")
    def verify_criteria(self):
        if {item.criterion_id for item in self.criteria} != set(_CRITERION_ISSUES):
            raise ValueError("必须且只能各评一次C01到C06")
        verdicts = {item.verdict for item in self.criteria}
        expected = "insufficient" if "unknown" in verdicts else "needs_changes" if "fail" in verdicts else "pass"
        if self.overall != expected:
            raise ValueError("overall必须与六项判定一致，未知材料不能判通过")
        return self

"""S08被测提示r3的本地材料/请求/预算核对；没有收费执行入口。"""

import difflib
import json
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
V2 = HERE.parent.parent
ROOT = next(parent for parent in HERE.parents if (parent / "backend").is_dir())
PREP_R1 = V2 / "S08-评价准备/20261022-r1"
RUN_R1 = V2 / "S08-评价运行/20261022-flash-pro-r1"
sys.path.insert(0, str(ROOT / "backend"))

from app.ai.client import AIClient
from app.ai.provider import AICompletionRequest, AIProvider, AIResponseFormat
from app.context.project_context import ProjectContext
from app.practice.agent import PRACTICE_CONTEXT_FIELDS
from app.practice.review import (
    PRACTICE_REVIEW_PROMPT_VERSION,
    PRACTICE_REVIEW_SCHEMA_VERSION,
    PracticeReviewAgent,
    PracticeReviewDraft,
    get_review_vectors,
)


class NoCallProvider(AIProvider):
    calls = 0

    @property
    def name(self):
        return "local_request_construction_only"

    async def complete(self, request):
        self.calls += 1
        raise AssertionError("本检查禁止Provider调用")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(name, value):
    (HERE / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def money(value):
    return format(value, ".8f")


def payload(request):
    return {
        "model": request.model,
        "messages": [
            {"role": item.role.value, "content": item.content}
            for item in request.messages
        ],
        "temperature": request.temperature,
        "stream": False,
        "max_tokens": request.max_tokens,
        "response_format": {"type": "json_object"},
        "thinking": {"type": "disabled"},
    }


def input_bound(messages):
    return len(json.dumps(messages, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) + 512


def cost(input_tokens, output_tokens, model, pricing):
    price = pricing["models"][model]["peak"]
    return (
        Decimal(input_tokens) * Decimal(price["input_cache_miss"])
        + Decimal(output_tokens) * Decimal(price["output"])
    ) / Decimal(pricing["unit_tokens"])


def main():
    checks = []

    def check(name, value):
        checks.append({"name": name, "passed": bool(value)})
        if not value:
            raise AssertionError(name)

    contract = read(V2 / "S01-AI固定模板与评价案例.json")
    old_params = read(RUN_R1 / "parameters.json")
    ledger = read(RUN_R1 / "ledger.json")
    old_role = (V2 / "S08-评价运行/20261024-flash-pro-r3/review-role-instruction.txt").read_text(encoding="utf-8").removesuffix("\n")
    new_role = PracticeReviewAgent.role_instruction
    edits = [opcode for opcode in difflib.SequenceMatcher(None, old_role, new_role, autojunk=False).get_opcodes() if opcode[0] != "equal"]
    check("prompt_r3_schema_1_0", PRACTICE_REVIEW_PROMPT_VERSION == "practice-review-r3" and PRACTICE_REVIEW_SCHEMA_VERSION == "practice-review/1.0")
    check("one_instruction_insert_original_role_preserved", len(edits) == 1 and edits[0][0] == "insert")
    required_keys = ("criterion_id", "verdict", "issue_type", "evidence_span", "reason", "suggested_self_test", "next_action")
    check("all_seven_keys_explicit_in_new_contract", all(key in new_role for key in required_keys) and "七个键" in new_role)
    check("fail_self_test_and_next_action_must_not_be_omitted", "不因Schema允许null而省略键" in new_role and "均须为非空字符串" in new_role)
    check("original_r2_c04_attribution_rules_preserved", "独立于C02/C03" in new_role and "sum_error" in new_role and old_role in new_role.replace(new_role[new_role.index("字段完整性约束："):new_role.index("attempt身份和版本由服务器绑定")], "", 1))
    check("schema_unchanged", PracticeReviewDraft.model_json_schema() == read(PREP_R1 / "review-draft-schema.json"))
    check("all_16_frozen_cases", [item["case_id"] for item in contract["cases"]] == [f"Q{number:02}" for number in range(1, 17)])
    check("frozen_denominators_unchanged", read(PREP_R1 / "case-index.json")["ground_truth_counts"] == contract["ground_truth_counts"])
    check("no_case_labels_in_role", not any(value in new_role for value in ("Q07", "Q09", "Q10", "reference_criteria", "reference_issues", "reference_label", "reference_code", "quality_gate")))
    (HERE / "review-role-instruction.txt").write_text(new_role + "\n", encoding="utf-8")

    params = json.loads(json.dumps(old_params))
    params["evaluation_id"] = "S08-review-r3-proposed-not-authorized"
    params["roles"]["under_test"]["prompt_version"] = "practice-review-r3"
    write("proposed-parameters.json", params)
    pricing = read(HERE / "pricing-basis.json")
    check("official_price_units_match_previous", pricing["currency"] == "CNY" and pricing["unit_tokens"] == 1000000 and pricing["models"] == read(RUN_R1 / "pricing-basis.json")["models"])

    context = ProjectContext.from_storage(read(RUN_R1 / "fixed-context.json"))
    provider = NoCallProvider()
    client = AIClient(provider, total_timeout_seconds=60, max_retries=0,
                      retry_base_delay_seconds=0, max_retry_delay_seconds=0)
    agent = PracticeReviewAgent(client, model="deepseek-flash", max_tokens=1500, temperature=0)
    rows = []
    for case in contract["cases"]:
        case_id = case["case_id"]
        data = read(PREP_R1 / f"agent-input-templates/{case_id}-input.json")
        check(f"{case_id}_same_code_and_statement", data["code"] == case["student_code"] and data["self_statement"] == case["self_statement"])
        check(f"{case_id}_same_selected_vectors", data["public_output_vectors"] == get_review_vectors(case["test_ids"]))
        check(f"{case_id}_no_reference_fields", not any(key.startswith("reference") or key in {"quality_gate", "rubric"} for key in data))
        messages = agent._build_messages(context, agent.validate_input(data), context_fields=PRACTICE_CONTEXT_FIELDS)
        request = AICompletionRequest(messages=messages, model="deepseek-flash", temperature=0,
                                      max_tokens=1500, response_format=AIResponseFormat.JSON_OBJECT,
                                      reasoning_enabled=False)
        new_payload = payload(request)
        previous = next(item for item in ledger["attempts"] if item["role"] == "under_test" and item["input_id"] == case_id)
        old_payload = read(RUN_R1 / previous["raw_request_ref"])
        check(f"{case_id}_system_only_expected_instruction_change", new_payload["messages"][0]["content"] == old_payload["messages"][0]["content"].replace((PREP_R1 / "review-role-instruction.txt").read_text(encoding="utf-8").removesuffix("\n"), new_role, 1))
        normalized = json.loads(json.dumps(new_payload))
        normalized["messages"][0]["content"] = old_payload["messages"][0]["content"]
        check(f"{case_id}_all_other_payload_fields_identical", normalized == old_payload)
        check(f"{case_id}_message_and_aggregate_limits", max(len(item.content) for item in messages) <= 12000 and sum(len(item.content) for item in messages) <= 24000)
        bound = input_bound(new_payload["messages"])
        rows.append({
            "case_id": case_id, "input_ref": f"../20261022-r1/agent-input-templates/{case_id}-input.json",
            "test_ids": case["test_ids"], "input_upper_tokens": bound, "output_cap": 1500,
            "request_characters": sum(len(item.content) for item in messages),
            "maximum_message_characters": max(len(item.content) for item in messages),
            "new_input_upper_token_delta": bound - previous["input_upper_tokens"],
            "reservation_upper_cny": money(cost(bound, 1500, "deepseek-flash", pricing)),
            "comparison": "only_expected_system_instruction_changed",
        })

    cases = {item["case_id"]: item for item in contract["cases"]}
    contrast = [
        {"case_id": key, "C03": cases[key]["reference_criteria"]["C03"],
         "C04": cases[key]["reference_criteria"]["C04"]}
        for key in ("Q07", "Q10", "Q09")
    ]
    check("classification_vs_real_accumulation_contrast_unchanged", [(row["C03"], row["C04"]) for row in contrast] == [("fail", "pass"), ("fail", "pass"), ("pass", "fail")])

    cal_attempts = [item for item in ledger["attempts"] if item["role"] == "judge_calibration"]
    judge_prompt = (PREP_R1 / "judge-r4-system.txt").read_text(encoding="utf-8").strip()
    check("prior_pro_calibration_passed_3_of_3", ledger["calibration_passed"] and len(cal_attempts) == 3 and all(item["calibration_expected_match"] for item in cal_attempts))
    check("judge_role_parameters_unchanged", all(params["roles"][role] == old_params["roles"][role] for role in ("judge_calibration", "judge_formal")))
    cal_refs = []
    for attempt in cal_attempts:
        key = attempt["input_id"]
        request = read(RUN_R1 / attempt["raw_request_ref"])
        check(f"{key}_same_judge_prompt_and_material", request["messages"][0]["content"] == judge_prompt and json.loads(request["messages"][1]["content"]) == read(PREP_R1 / f"calibration-inputs/{key}-input.json"))
        check(f"{key}_all_frozen_calibration_expectations_matched", read(RUN_R1 / f"validations/{key}.json")["calibration_pass"])
        cal_refs.append({"case_id": key, "raw_response_ref": f"../../S08-评价运行/20261022-flash-pro-r1/{attempt['raw_response_ref']}", "system_fingerprint": attempt["response_system_fingerprint"], "matched": True})
    check("documented_judge_version_unchanged", params["roles"]["judge_formal"]["documented_service_version"] == pricing["models"]["deepseek-v4-pro"]["documented_service_version"])
    check("zero_provider_calls", provider.calls == 0)

    previous_fee = sum((Decimal(item["budget_charged_upper_cny"]) for item in ledger["attempts"] if item["role"] in {"under_test", "judge_formal"}), Decimal(0))
    extra_input_cost = sum((cost(row["new_input_upper_token_delta"], 0, "deepseek-flash", pricing) for row in rows), Decimal(0))
    historical_formal = [item for item in ledger["attempts"] if item["role"] == "judge_formal"]
    reference_formal_reserve = sum((Decimal(item["reservation_upper_cny"]) for item in historical_formal), Decimal(0))
    tested_reserve = sum((Decimal(row["reservation_upper_cny"]) for row in rows), Decimal(0))
    budget = {
        "status": "proposal_only_not_authorized_not_run", "currency": "CNY",
        "actual_authorized_new_calls": 0, "actual_model_calls_this_task": 0, "actual_fee_this_task": "0.00000000",
        "proposed_role_limits": {"under_test": 16, "judge_formal": 16, "judge_calibration": 0},
        "proposed_total_call_limit": 32, "proposed_currency_hard_cap": "1.56296800",
        "under_test_model": "deepseek-flash", "under_test_prompt": "practice-review-r3",
        "judge_model": "deepseek-v4-pro", "judge_prompt": "judge-r4", "max_retries": 0, "transport_retries": 0,
        "input_scope": "固定Q01-Q16原代码/声明/各自指定向量和原合成Context；J1另见单例冻结参考及新候选，隐藏被测身份",
        "calibration_reuse": "local_materials_eligible_execution_recheck_required",
        "calibration_source_ref": "../../S08-评价运行/20261022-flash-pro-r1/ledger.json",
        "calibration_raw_refs": cal_refs,
        "reuse_conditions": "provider、精确model_id/服务版本、judge-r4原文、采样/输出/超时/重试参数及G01-G03材料/预期不变；仅被测prompt变为r3不改变J1配置",
        "reuse_failure_policy": "执行前不满足可见条件即停止；响应发现服务fingerprint变化即停止；不得自动追加校准或借用正式角色次数",
        "tested_known_max_reservation_sum_cny": money(tested_reserve),
        "prior_same_roles_actual_usage_peak_upper_cny": money(previous_fee),
        "new_prompt_additional_input_utf8_upper_cost_cny": money(extra_input_cost),
        "reference_scenario_previous_usage_plus_prompt_upper_cny": money(previous_fee + extra_input_cost),
        "reference_formal_reservations_from_old_candidates_cny": money(reference_formal_reserve),
        "reference_all_max_reservations_with_old_candidates_cny": money(tested_reserve + reference_formal_reserve),
        "reference_scenario_is_quote_or_actual_charge": False,
        "full_round_under_cap_guaranteed": False,
        "formal_judge_cost": "依赖尚未生成的新candidate，必须逐例按实际完整messages重新预留；旧candidate只作预算参考，不送作新轮结果",
        "reservation_rule": "每POST前先计次并写账，以UTF8紧凑messages字节+512协议余量、输出上限和峰价全cachemiss预留；spent_or_held_upper+next_max<=1.562968CNY才允许发送",
        "settlement_rule": "成功按原始usage同口径峰价上界结算；失败占次数并保留预留，无自动重试/补例/调参",
        "stop_policy": "Provider/结构/正式弃权无效/预算不足立即停止，常规质量失误保留并按固定顺序收齐16例；完成本轮停止，不进入S09",
        "authorization_gate": "本轮用户授权本地修复；本文件仅方案，收费仍0许可；新轮需明确32次和合计1.562968CNY硬限，Pro校准不符合复用条件则停止",
        "account_balance_queried": False, "account_charge_reconciled": False,
        "previous_r2_and_continuation_spent_or_held_cny": "0.43703200", "combined_original_r2_cap_cny": "2.00000000", "original_unspent_hard_cap_not_account_balance_cny": "1.56296800", "role_quota_gap": {"remaining_under_test": 9, "remaining_judge_formal": 10, "additional_under_test": 7, "additional_judge_formal": 6}, "full_new_prompt_16_cases_required": True, "old_candidates_reused_for_quality": False,
    }
    write("budget-plan.json", budget)
    write("request-preflight.json", {"status": "passed", "model_calls": 0, "requests_constructed_locally": 16, "requests": rows})
    write("local-checks.json", {
        "checked_at": datetime.now(timezone(timedelta(hours=8))).isoformat(),
        "status": "passed", "checks_passed": len(checks), "checks": checks,
        "fixed_contrast_expectations_evaluator_only": contrast,
        "prompt_insert_characters": len(new_role) - len(old_role),
        "prompt_insert_utf8_bytes": len(new_role.encode("utf-8")) - len(old_role.encode("utf-8")),
        "real_model_calls": 0, "provider_calls_in_verifier": provider.calls,
        "database_access": False, "credentials_read": False, "student_code_executed_or_compiled": False,
        "quality_status": "r3_not_evaluated_prior_failures_and_invalid_responses_preserved",
    })
    print(json.dumps({"status": "passed", "checks": len(checks), "requests_constructed": 16, "model_calls": 0,
                      "proposed_calls": 32, "proposed_cap_cny": "1.56296800",
                      "reference_scenario_cny": budget["reference_scenario_previous_usage_plus_prompt_upper_cny"],
                      "reference_max_reservations_cny": budget["reference_all_max_reservations_with_old_candidates_cny"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

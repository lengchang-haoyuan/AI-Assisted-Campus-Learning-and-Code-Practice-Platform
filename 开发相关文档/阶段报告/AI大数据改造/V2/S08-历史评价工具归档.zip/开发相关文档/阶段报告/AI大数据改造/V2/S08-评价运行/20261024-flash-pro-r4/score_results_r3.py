"""离线重现冻结S08计分；默认未运行，不请求模型、不执行学生代码。"""

import argparse
import json
from pathlib import Path
import sys

from validate_judge import validate_feedback
from frozen_review_schema import PracticeReviewDraft

HERE = Path(__file__).resolve().parent
V2 = HERE.parent.parent
ROOT = next(parent for parent in HERE.parents if (parent / "backend").is_dir())


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def summarize(candidate_dir: Path | None, judge_dir: Path | None, *, run_dir: Path | None = None, legacy_method: bool = False) -> dict:
    run_dir = run_dir or HERE
    contract = load(HERE / "frozen-reference-contract.json")
    result = {
        "status": "not_run", "contract_id": contract["contract_id"],
        "quality_metrics": None, "rule_gates": None,
        "current_calibration": "not_verified_by_this_script",
        "complete_quality_acceptance": "not_asserted_requires_authorization_raw_usage_and_current_calibration",
        "model_calls_by_this_script": 0, "database_access": False,
        "evaluation_usage_source": "separate_role_ledger_not_inferred_from_file_count",
        "frozen_denominators": {"reference_issue_cells": 9, "known_pass_cells": 69, "unknown_cells": 18},
    }
    if candidate_dir is None or judge_dir is None:
        result["unrun_reason"] = "no_real_candidate_and_judge_directories_supplied"
        return result
    # 历史解释只绑定该轮快照；当前生产提示词仅由新调用preflight核对。
    snapshot_dir = run_dir
    if run_dir.name == "20261022-flash-pro-r1":
        snapshot_dir = V2 / "S08-评价准备/20261022-r1"
    binding = load(snapshot_dir / "production-contract-binding.json")
    if PracticeReviewDraft.model_json_schema() != load(snapshot_dir / "review-draft-schema.json"):
        result.update(status="not_completed", unresolved=[{"status": "frozen_schema_not_supported"}])
        return result
    prompt_version = binding["review_prompt_version"]
    if prompt_version not in {"practice-review-r1", "practice-review-r2", "practice-review-r3"} or binding["review_schema_version"] != "practice-review/1.0":
        result.update(status="not_completed", unresolved=[{"status": "frozen_version_not_supported"}])
        return result
    suffix, text_version = {"practice-review-r1": ("v1", "1.0"), "practice-review-r2": ("v2", "2.0"), "practice-review-r3": ("v3", "3.0")}[prompt_version]
    if not legacy_method:
        result["evaluation_method_version"] = "evaluation-method-r3"
    def validate(input_obj, response):
        if not legacy_method:
            return validate_feedback(input_obj, response)
        # 旧方法只用于复现历史成绩，不能作为修复后验收结果。
        import importlib.util
        spec = importlib.util.spec_from_file_location("s08_legacy_quote_validator", V2 / "S08-评价准备/20261022-r1/validate_judge.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.validate_feedback(input_obj, response)

    candidates = {}
    judges = {}
    unavailable = []
    unsupported_issue_cells = set()
    unresolved_issue_cells = set()
    for case in contract["cases"]:
        cid = case["case_id"]
        candidate_path = candidate_dir / f"{cid}-response.json"
        judge_path = judge_dir / f"{cid}-response.json"
        judge_input_path = judge_dir / f"{cid}-input.json"
        missing = [path.name for path in (candidate_path, judge_path, judge_input_path) if not path.is_file()]
        if missing:
            unavailable.append({"case_id": cid, "status": "not_run", "missing_files": missing})
            continue
        try:
            envelope = load(candidate_path)
            if envelope["case_id"] != cid or envelope["artifact_id"] != f"S08-{cid}-candidate-{suffix}" or envelope["text_version"] != text_version:
                raise ValueError("candidate_binding_mismatch")
            raw_candidate = envelope["response"]
            candidate = PracticeReviewDraft.model_validate(raw_candidate)
            code = case["student_code"] or ""
            for item in candidate.criteria:
                if item.evidence_span is not None and item.evidence_span not in code:
                    raise ValueError("candidate_evidence_not_in_case_code")
            if not code.strip() and any(item.verdict != "unknown" for item in candidate.criteria):
                raise ValueError("missing_code_definitive_verdict")
            judge_input = load(judge_input_path)
            expected_input = load(V2 / "S08-评价准备/20261022-r1" / f"judge-input-templates/{cid}-input.json")
            expected_input["data"]["candidate_feedback"] = json.dumps(raw_candidate, ensure_ascii=False, indent=2)
            if judge_input != expected_input:
                raise ValueError("judge_input_not_bound_to_frozen_case_and_candidate_text")
            judge_envelope = load(judge_path)
            if judge_envelope["case_id"] != cid or judge_envelope["candidate_artifact_id"] != envelope["artifact_id"] or judge_envelope["candidate_text_version"] != envelope["text_version"]:
                raise ValueError("judge_candidate_binding_mismatch")
            judge_response = judge_envelope["response"]
            # 顶层unsupported_claim不能覆盖逐criterion证据否定；每个单元只计一次。
            evidence_rows = judge_response.get("criterion_evidence", []) if isinstance(judge_response, dict) else []
            if not isinstance(evidence_rows, list):
                evidence_rows = []
            for item in candidate.criteria:
                if item.verdict not in ({"fail"} if legacy_method else {"pass", "fail"}):
                    continue
                matches = [row for row in evidence_rows if isinstance(row, dict) and row.get("criterion_id") == item.criterion_id]
                flag = matches[0].get("evidence_valid") if len(matches) == 1 else None
                cell = (cid, item.criterion_id)
                if flag is False:
                    unsupported_issue_cells.add(cell)
                elif flag is None:
                    unresolved_issue_cells.add(cell)
            validation = validate(judge_input, judge_response)
            if not validation.get("structure_binding_and_quotes_valid"):
                unavailable.append({"case_id": cid, "status": "invalid", "validation_errors": validation["errors"]})
                continue
            if judge_response["status"] != "scored":
                unavailable.append({"case_id": cid, "status": judge_response["status"], "reason": "unresolved_judge_no_forced_zero"})
                continue
            candidates[cid] = candidate
            judges[cid] = judge_response
        except Exception as exc:
            # 不输出原响应、引用、正文或异常完整内容。
            unavailable.append({"case_id": cid, "status": "invalid", "error_type": type(exc).__name__})
    if unavailable:
        result.update(
            status="not_completed", unresolved=unavailable, all_rule_gates_pass=False,
            observed_issue_cell_flags={
                "unsupported_issue_cells": len(unsupported_issue_cells),
                "unresolved_issue_cells": len(unresolved_issue_cells),
                "unsupported_cells": [list(cell) for cell in sorted(unsupported_issue_cells)],
                "unresolved_cells": [list(cell) for cell in sorted(unresolved_issue_cells)],
                "scope": "observed_valid_candidate_fail_cells_not_a_reduced_scoring_denominator" if legacy_method else "observed_definitive_pass_or_fail_cells_not_a_reduced_scoring_denominator",
            },
        )
        return result
    tp = fp = 0
    incorrect_passes = correct_confirmations = insufficient_detected = insufficient_passes = 0
    unknown_definitive_cells = unsupported_claims = 0
    actionability = []
    details = []
    for case in contract["cases"]:
        cid = case["case_id"]
        candidate = candidates[cid]
        judge = judges[cid]
        verdicts = {item.criterion_id: item.verdict for item in candidate.criteria}
        evidence = {item["criterion_id"]: item["evidence_valid"] for item in judge["criterion_evidence"]}
        case_tp = case_fp = case_fn = 0
        for criterion_id, reference in case["reference_criteria"].items():
            if reference == "fail":
                if verdicts[criterion_id] == "fail" and evidence[criterion_id] is True:
                    case_tp += 1
                else:
                    case_fn += 1
            elif reference == "pass" and verdicts[criterion_id] == "fail":
                case_fp += 1
            elif reference == "unknown" and verdicts[criterion_id] != "unknown":
                unknown_definitive_cells += 1
        tp += case_tp
        fp += case_fp
        unsupported_claims += int(judge["unsupported_claim"] is True)
        if case["reference_label"] == "needs_changes":
            incorrect_passes += int(candidate.overall == "pass")
            effective_score = 0 if case_fn else judge["actionability_score"]
            actionability.append({"case_id": cid, "score": effective_score, "raw_judge_score": judge["actionability_score"], "source": "frozen_miss_override_zero" if case_fn else "judge"})
        elif case["reference_label"] == "pass":
            correct_confirmations += int(candidate.overall == "pass")
        else:
            insufficient_detected += int(candidate.overall == "insufficient")
            insufficient_passes += int(candidate.overall == "pass")
        details.append({"case_id": cid, "TP": case_tp, "FN": case_fn, "FP": case_fp,
                        "unsupported_issue_cells": sum(cell[0] == cid for cell in unsupported_issue_cells),
                        "unresolved_issue_cells": sum(cell[0] == cid for cell in unresolved_issue_cells)})
    fn = 9 - tp
    precision_denominator = tp + fp
    actionable_count = sum(row["score"] >= 2 for row in actionability)
    actionability_sum = sum(row["score"] for row in actionability)
    gates = {
        "issue_recall": tp >= 8 and fn <= 1,
        "precision": precision_denominator > 0 and 5 * tp >= 4 * precision_denominator,
        "false_positive_rate": fp <= 3 and 20 * fp <= 69,
        "incorrect_passes": incorrect_passes == 0,
        "insufficient": insufficient_detected == 3 and insufficient_passes == 0 and unknown_definitive_cells == 0,
        "correct_confirmations": correct_confirmations >= 3,
        "actionability": actionable_count >= 8 and len(actionability) == 9 and actionability_sum >= 18,
        "unsupported_definitive_claims": unsupported_claims == 0 and not unsupported_issue_cells and not unresolved_issue_cells,
        "responses_and_judge_items": len(candidates) == len(judges) == 16,
    }
    result.update(
        status="not_completed" if unresolved_issue_cells else "rules_computed_current_calibration_and_authorization_separate",
        quality_metrics={"TP": tp, "FN": fn, "FP": fp, "recall": f"{tp}/9", "precision": f"{tp}/{precision_denominator}" if precision_denominator else None, "false_positive_rate": f"{fp}/69", "incorrect_passes": f"{incorrect_passes}/9", "insufficient_detection": f"{insufficient_detected}/3", "insufficient_passes": f"{insufficient_passes}/3", "correct_confirmations": f"{correct_confirmations}/4", "unknown_definitive_cells": unknown_definitive_cells, "unsupported_claims": unsupported_claims, "unsupported_issue_cells": len(unsupported_issue_cells), "unresolved_issue_cells": len(unresolved_issue_cells), "actionable_error_feedback": f"{actionable_count}/9", "actionability_mean": f"{actionability_sum}/9", "actionability": actionability, "per_case_cells": details},
        rule_gates=gates, all_rule_gates_pass=all(gates.values()),
    )
    if not legacy_method and result.get("quality_metrics") is not None:
        result["quality_metrics"]["unsupported_definitive_cells"] = len(unsupported_issue_cells)
        result["quality_metrics"]["unresolved_definitive_cells"] = len(unresolved_issue_cells)
        result["definitive_evidence_scope"] = "pass_and_fail; unknown_is_not_definitive"
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-dir", type=Path)
    parser.add_argument("--judge-dir", type=Path)
    args = parser.parse_args()
    result = summarize(args.candidate_dir, args.judge_dir)
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 1 if result["status"] == "not_completed" else 0


if __name__ == "__main__":
    raise SystemExit(main())

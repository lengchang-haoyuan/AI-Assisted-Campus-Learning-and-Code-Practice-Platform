"""校验J1单例响应；只读JSON，不执行代码、不导入配置或发送请求。"""

import argparse
import json
from pathlib import Path

STATUSES = {"scored", "abstain", "invalid"}
CRITERION_IDS = {f"C{i:02}" for i in range(1, 7)}
CASE_IDS = {f"Q{i:02}" for i in range(1, 17)} | {"G01", "G02", "G03"}


def feedback_corpus(data: dict) -> list[str]:
    """JSON只解码一层；每个字段独立保留，绝不拼接或全局替换转义符。"""
    corpus = [value for value in (data.get("student_code"), data.get("candidate_feedback")) if isinstance(value, str)]
    if isinstance(data.get("reference"), dict):
        corpus.append(json.dumps(data["reference"], ensure_ascii=False, indent=2))
    feedback = data.get("candidate_feedback")
    if isinstance(feedback, str):
        try:
            decoded = json.loads(feedback)
        except (ValueError, TypeError):
            decoded = None
        if isinstance(decoded, (dict, list)):
            def collect(value):
                if isinstance(value, str):
                    corpus.append(value)
                elif isinstance(value, dict):
                    for item in value.values():
                        collect(item)
                elif isinstance(value, list):
                    for item in value:
                        collect(item)
            collect(decoded)
    return corpus


def validate_feedback(input_obj: dict, response: object, expected: dict | None = None) -> dict:
    errors = []
    if not isinstance(input_obj, dict):
        input_obj = {}
    data = input_obj.get("data", {})
    if not isinstance(data, dict):
        data = {}
    case_id = data.get("case_id")
    criterion_ids = data.get("criterion_ids")
    if input_obj.get("mode") != "feedback" or not isinstance(case_id, str) or case_id not in CASE_IDS:
        errors.append("invalid_input_identity")
    if not isinstance(criterion_ids, list) or not criterion_ids or not all(isinstance(item, str) for item in criterion_ids) or len(criterion_ids) != len(set(criterion_ids)) or not set(criterion_ids) <= CRITERION_IDS:
        errors.append("invalid_input_criterion_ids")
        criterion_ids = []
    if not isinstance(response, dict):
        return {"case_id": case_id, "status": "invalid", "errors": errors + ["response_not_object"], "calibration_pass": False}
    fields = {"case_id", "status", "criterion_evidence", "actionability_score", "unsupported_claim", "reason"}
    if set(response) != fields:
        errors.append("response_fields_mismatch")
    if response.get("case_id") != case_id:
        errors.append("case_binding_mismatch")
    status = response.get("status")
    if not isinstance(status, str) or status not in STATUSES:
        errors.append("invalid_status")
    scored = status == "scored"
    if not isinstance(response.get("reason"), str) or not response["reason"].strip():
        errors.append("empty_response_reason")
    score = response.get("actionability_score")
    if (scored and (type(score) is not int or not 0 <= score <= 3)) or (not scored and score is not None):
        errors.append("invalid_actionability_score")
    unsupported = response.get("unsupported_claim")
    if (scored and type(unsupported) is not bool) or (not scored and unsupported is not None):
        errors.append("invalid_unsupported_claim")
    evidence = response.get("criterion_evidence")
    if not isinstance(evidence, list):
        errors.append("criterion_evidence_not_list")
        evidence = []
    ids = []
    corpus = feedback_corpus(data)
    reference_checks = []
    for index, item in enumerate(evidence):
        if not isinstance(item, dict) or set(item) != {"criterion_id", "evidence_valid", "quote", "reason"}:
            errors.append(f"evidence_{index}_fields_mismatch")
            continue
        if isinstance(item["criterion_id"], str):
            ids.append(item["criterion_id"])
        else:
            errors.append(f"evidence_{index}_invalid_criterion")
        flag = item["evidence_valid"]
        if (scored and type(flag) is not bool) or (not scored and flag is not None):
            errors.append(f"evidence_{index}_invalid_flag")
        if not isinstance(item["reason"], str) or not item["reason"].strip():
            errors.append(f"evidence_{index}_empty_reason")
        quote = item["quote"]
        present = isinstance(quote, str) and bool(quote) and any(quote in value for value in corpus)
        valid = present or (not scored and quote == "")
        reference_checks.append({"criterion_id": item["criterion_id"], "quote_present": present, "valid": valid})
        if not valid:
            errors.append(f"evidence_{index}_quote_not_contiguous_source_text")
    if sorted(ids) != sorted(criterion_ids):
        errors.append("criterion_binding_missing_duplicate_or_extra")
    calibration_matches = {}
    if isinstance(expected, dict):
        first = evidence[0] if len(evidence) == 1 and isinstance(evidence[0], dict) else {}
        actual = {"calibration_id": response.get("case_id"), "expected_status": status, "expected_actionability_score": score, "expected_criterion": first.get("criterion_id"), "expected_evidence_valid": first.get("evidence_valid"), "expected_unsupported_claim": unsupported}
        calibration_matches = {key: key in expected and type(value) is type(expected[key]) and value == expected[key] for key, value in actual.items()}
    return {"case_id": case_id, "status": "invalid" if errors else status, "structure_binding_and_quotes_valid": not errors, "reference_checks": reference_checks, "calibration_expected_matches": calibration_matches, "calibration_pass": bool(calibration_matches) and not errors and all(calibration_matches.values()), "errors": errors, "semantic_evidence_note": "quote存在仅证明可定位；evidence_valid语义仍是J1判断，不是规则重新生成"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--response", type=Path, required=True)
    parser.add_argument("--expected", type=Path)
    args = parser.parse_args()
    input_obj = json.loads(args.input.read_text(encoding="utf-8-sig"))
    response = json.loads(args.response.read_text(encoding="utf-8-sig"))
    expected = None
    if args.expected:
        expected_obj = json.loads(args.expected.read_text(encoding="utf-8-sig"))
        cases = expected_obj.get("cases", [])
        expected = next((case for case in cases if case.get("calibration_id") == input_obj["data"]["case_id"]), None)
    result = validate_feedback(input_obj, response, expected)
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result.get("structure_binding_and_quotes_valid") else 1


if __name__ == "__main__":
    raise SystemExit(main())

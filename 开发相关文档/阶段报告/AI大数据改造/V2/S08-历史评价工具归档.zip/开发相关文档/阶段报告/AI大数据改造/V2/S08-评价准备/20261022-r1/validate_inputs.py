"""只读核对S08离线准备；不读取应用配置、不执行学生代码。"""

import json
from pathlib import Path
import sys
from uuid import NAMESPACE_URL, uuid5

HERE = Path(__file__).resolve().parent
V2 = HERE.parent.parent
PRIOR = V2 / "S06-J1运行/20261021-deepseek-flash-r3-judge-r4"
FORBIDDEN = {
    "reference_code", "reference_code_for_evaluation_only", "reference_label",
    "reference_criteria", "reference_issues", "reference_action", "quality_gate",
    "raters", "budget", "syntactically_complete", "ground_truth_counts",
}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def all_keys(value):
    if isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from all_keys(child)
    elif isinstance(value, list):
        for child in value:
            yield from all_keys(child)


def validate() -> dict:
    root = next(parent for parent in HERE.parents if (parent / "backend").is_dir())
    sys.path.insert(0, str(root / "backend"))
    from app.practice.review import (
        PracticeReviewAgent, PracticeReviewDraft, PracticeReviewInput,
        PRACTICE_REVIEW_PROMPT_VERSION, PRACTICE_REVIEW_SCHEMA_VERSION, get_review_vectors,
    )

    contract = load(V2 / "S01-AI固定模板与评价案例.json")
    index = load(HERE / "case-index.json")
    vectors = {row["test_id"]: row for row in contract["fixed_output_vectors"]}
    checks = []

    def check(label: str, condition: bool) -> None:
        checks.append({"check": label, "passed": bool(condition)})

    check("frozen_contract", contract["contract_id"] == "V2-S01-r2")
    check("six_criteria", [row["criterion_id"] for row in contract["criteria"]] == [f"C{i:02}" for i in range(1, 7)])
    check("seven_vectors", list(vectors) == [f"T{i:02}" for i in range(1, 8)])
    check("sixteen_cases", [row["case_id"] for row in contract["cases"]] == [f"Q{i:02}" for i in range(1, 17)])
    computed = {
        "cases": len(contract["cases"]),
        "correct": sum(row["reference_label"] == "pass" for row in contract["cases"]),
        "incorrect": sum(row["reference_label"] == "needs_changes" for row in contract["cases"]),
        "insufficient": sum(row["reference_label"] == "insufficient" for row in contract["cases"]),
        "known_criterion_cells": sum(value != "unknown" for row in contract["cases"] for value in row["reference_criteria"].values()),
        "reference_issue_cells": sum(value == "fail" for row in contract["cases"] for value in row["reference_criteria"].values()),
        "known_pass_cells": sum(value == "pass" for row in contract["cases"] for value in row["reference_criteria"].values()),
        "unknown_cells": sum(value == "unknown" for row in contract["cases"] for value in row["reference_criteria"].values()),
    }
    check("frozen_denominators", computed == contract["ground_truth_counts"] == {"cases": 16, "correct": 4, "incorrect": 9, "insufficient": 3, "known_criterion_cells": 78, "reference_issue_cells": 9, "known_pass_cells": 69, "unknown_cells": 18})
    check("index_denominators", index["ground_truth_counts"] == computed)
    indexed = {row["case_id"]: row for row in index["cases"]}
    for case in contract["cases"]:
        cid = case["case_id"]
        tested = load(HERE / f"under-test/{cid}-input.json")
        judge = load(HERE / f"judge-input-templates/{cid}-input.json")
        check(cid + ":input_identity", (tested["case_id"], tested["template_id"], tested["template_version"]) == (cid, "python-learning-csv", "1.0"))
        check(cid + ":task_criteria", tested["task"] == contract["task"] and tested["criteria"] == contract["criteria"])
        check(cid + ":case_code_and_claim", tested["student_code"] == case["student_code"] and tested["self_statement"] == case["self_statement"])
        check(cid + ":selected_vectors_exact", tested["public_output_vectors"] == [vectors[tid] for tid in case["test_ids"]])
        check(cid + ":reference_not_leaked", not (set(all_keys(tested)) & FORBIDDEN))
        check(cid + ":index_binding", indexed[cid]["test_ids"] == case["test_ids"] and indexed[cid]["reference_label"] == case["reference_label"])
        data = judge["data"]
        check(cid + ":judge_identity", judge["mode"] == "feedback" and data["case_id"] == cid and data["criterion_ids"] == [f"C{i:02}" for i in range(1, 7)])
        check(cid + ":judge_reference", data["reference"] == {key: case[key] for key in ("reference_label", "reference_criteria", "reference_issues", "reference_action")})
        check(cid + ":candidate_not_run", data["candidate_feedback"] is None)
        check(cid + ":judge_code", data["student_code"] == case["student_code"])
        bound = load(HERE / f"agent-input-templates/{cid}-input.json")
        expected_bound = {
            "template_id": "python-learning-csv", "template_version": "1.0", "context_version": 1,
            "attempt_id": str(uuid5(NAMESPACE_URL, f"S08-{cid}-candidate-v1")), "attempt_no": 1,
            "code": case["student_code"], "self_statement": case["self_statement"], "declared_output": {},
            "public_output_vectors": tested["public_output_vectors"],
        }
        check(cid + ":production_input_dto", PracticeReviewInput.model_validate(bound).model_dump(mode="json") == expected_bound)
    check("all_vectors_preserved", load(HERE / "fixed-vectors-reference.json")["vectors"] == contract["fixed_output_vectors"])
    check("original_judge_r4_unchanged", (HERE / "judge-r4-system.txt").read_text(encoding="utf-8") == (PRIOR / "judge-r4-system.txt").read_text(encoding="utf-8"))
    for item in contract["raters"]["calibration_cases"]:
        cid = item["calibration_id"]
        check(cid + ":original_input_unchanged", load(HERE / f"calibration-inputs/{cid}-input.json") == load(PRIOR / f"raw/{cid}-input.json"))
    check("frozen_calibration_expected", load(HERE / "calibration-expected.json")["cases"] == contract["raters"]["calibration_cases"])
    config = load(HERE / "judge-config-proposal.json")
    check("historical_parameters_exact", config["historical_parameters"] == load(PRIOR / "parameters.json"))
    check("reuse_unverified", config["current_reuse_status"] == "not_verified" and config["selected_exact_model_id"] is None)
    ledger = load(HERE / "role-ledger.json")
    check("zero_authorization", ledger["authorization"]["total_calls"] == 0 and ledger["authorization"]["input_permission"] is False)
    check("zero_actual_calls_and_cost", ledger["actual"]["total_calls"] == ledger["actual"]["cost"] == 0 and ledger["actual"]["raw_response_refs"] == [])
    budget = load(HERE / "budget-plan.json")
    check("proposal_not_permission", budget["actual_authorized_calls"] == 0 and budget["proposed_totals"]["formal_calls"] == 32 and budget["proposed_totals"]["with_new_calibration_calls"] == 35)
    check("zero_retry_no_quota_transfer", budget["max_retries"] == budget["transport_retries"] == 0 and budget["role_quota_transfer_allowed"] is False and budget["historical_S06"]["remaining_calls"] == 0)
    checklist = load(HERE / "evaluation-checklist.json")
    check("all_responses_unrun", len(checklist["cases"]) == 16 and all(row["candidate_response_ref"] is None and row["judge_response_ref"] is None for row in checklist["cases"]))
    binding = load(HERE / "production-contract-binding.json")
    check("production_versions_exact", binding["review_schema_version"] == PRACTICE_REVIEW_SCHEMA_VERSION == "practice-review/1.0" and binding["review_prompt_version"] == PRACTICE_REVIEW_PROMPT_VERSION == "practice-review-r1")
    check("production_model_output_schema_exact", load(HERE / "review-draft-schema.json") == PracticeReviewDraft.model_json_schema())
    check("production_role_instruction_exact", (HERE / "review-role-instruction.txt").read_text(encoding="utf-8") == PracticeReviewAgent.role_instruction + "\n")
    check("production_all_seven_vectors_exact", get_review_vectors(list(vectors)) == list(vectors.values()))
    return {"status": "passed" if all(row["passed"] for row in checks) else "failed", "check_count": len(checks), "passed": sum(row["passed"] for row in checks), "failed_checks": [row["check"] for row in checks if not row["passed"]], "ground_truth_counts": computed, "real_model_calls": 0, "student_code_executed": False, "database_access": False}


if __name__ == "__main__":
    result = validate()
    print(json.dumps(result, ensure_ascii=True, indent=2))
    raise SystemExit(0 if result["status"] == "passed" else 1)

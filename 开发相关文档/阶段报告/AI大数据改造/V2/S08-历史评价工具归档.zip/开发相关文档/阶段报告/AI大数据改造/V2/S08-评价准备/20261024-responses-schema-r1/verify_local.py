"""Schema协议的固定16例离线核对；没有收费执行入口。"""

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
V2 = HERE.parent.parent
ROOT = next(path for path in HERE.parents if (path / "backend").is_dir())
sys.path.insert(0, str(ROOT / "backend"))

from app.ai.client import AIClient
from app.ai.deepseek import DeepSeekProvider
from app.ai.provider import AIProvider, AIResponseFormat
from app.context.project_context import ProjectContext
from app.practice.agent import PRACTICE_CONTEXT_FIELDS
from app.practice.review import (
    PRACTICE_REVIEW_PROMPT_VERSION, PRACTICE_REVIEW_REQUEST_VERSION,
    PRACTICE_REVIEW_SCHEMA_VERSION, PracticeReviewAgent, PracticeReviewDraft,
    get_review_vectors,
)


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class NoCall(AIProvider):
    calls = 0

    @property
    def name(self):
        return "offline_only"

    async def complete(self, request):
        self.calls += 1
        raise AssertionError("离线检查禁止Provider调用")


def main():
    checks = []

    def check(name, condition):
        checks.append({"name": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)

    original = V2 / "S08-评价运行/20261022-flash-pro-r1"
    last = V2 / "S08-评价运行/20261024-flash-pro-r4"
    frozen = V2 / "S08-评价准备/20261022-r1"
    contract = read(V2 / "S01-AI固定模板与评价案例.json")
    context = ProjectContext.from_storage(read(last / "fixed-context.json"))
    previous = read(original / "ledger.json")
    provider = NoCall()
    agent = PracticeReviewAgent(AIClient(provider, total_timeout_seconds=60, max_retries=0,
                                       retry_base_delay_seconds=0, max_retry_delay_seconds=0),
                                model="deepseek-flash", max_tokens=1500, temperature=0)
    wire = agent._model_output_json_schema()
    old_role = (frozen / "review-role-instruction.txt").read_text(encoding="utf-8").removesuffix("\n")
    old_schema_text = json.dumps(read(frozen / "review-draft-schema.json"), ensure_ascii=False, separators=(",", ":"))
    new_schema_text = json.dumps(wire, ensure_ascii=False, separators=(",", ":"))
    check("new_prompt_and_protocol_frozen", PRACTICE_REVIEW_PROMPT_VERSION == "practice-review-r4" and PRACTICE_REVIEW_REQUEST_VERSION == "practice-review-responses-schema-r1")
    check("public_schema_unchanged", PRACTICE_REVIEW_SCHEMA_VERSION == "practice-review/1.0" and PracticeReviewDraft.model_json_schema() == read(last / "review-draft-schema.json"))
    check("role_text_identical_to_previous_r3", agent.role_instruction + "\n" == (last / "review-role-instruction.txt").read_text(encoding="utf-8"))
    check("wire_has_no_unresolved_refs", '"$ref"' not in new_schema_text)
    check("fixed16", [item["case_id"] for item in contract["cases"]] == [f"Q{i:02}" for i in range(1, 17)])
    variants = wire["properties"]["criteria"]["items"]["anyOf"]
    check("three_verdict_branches", [row["properties"]["verdict"]["enum"] for row in variants] == [["pass"], ["fail"], ["unknown"]])
    check("all_seven_fields_required", all(len(row["required"]) == 7 and set(row["required"]) == set(row["properties"]) and row["additionalProperties"] is False for row in variants))
    rows = []
    pricing = read(last / "pricing-basis.json")
    price = pricing["models"]["deepseek-flash"]["peak"]
    for case in contract["cases"]:
        cid = case["case_id"]
        data = read(frozen / f"agent-input-templates/{cid}-input.json")
        check(cid + "_code_and_statement", data["code"] == case["student_code"] and data["self_statement"] == case["self_statement"])
        check(cid + "_selected_vectors", data["public_output_vectors"] == get_review_vectors(case["test_ids"]))
        check(cid + "_no_reference_labels", not any(key.startswith("reference") or key in {"quality_gate", "rubric"} for key in data))
        request = agent._build_completion_request(context, agent.validate_input(data), context_fields=PRACTICE_CONTEXT_FIELDS)
        path, body = DeepSeekProvider._request_payload(request)
        check(cid + "_responses_schema_request", path == "/responses" and request.response_format == AIResponseFormat.JSON_SCHEMA and body["text"]["format"]["schema"] == wire)
        check(cid + "_nonthinking_single_response", body["reasoning"] == {"effort": "none"} and body["stream"] is False and body["max_output_tokens"] == 1500 and not any(key in body for key in ("tools", "previous_response_id", "headers")))
        old_row = next(row for row in previous["attempts"] if row["role"] == "under_test" and row["input_id"] == cid)
        old = read(original / old_row["raw_request_ref"])
        messages = [{"role": item.role.value, "content": item.content} for item in request.messages]
        check(cid + "_all_data_messages_unchanged", messages[1:] == old["messages"][1:])
        expected_system = old["messages"][0]["content"].replace(old_role, agent.role_instruction, 1).replace(old_schema_text, new_schema_text, 1)
        check(cid + "_only_expected_role_and_schema_changes", messages[0]["content"] == expected_system)
        check(cid + "_existing_message_limits", max(len(item.content) for item in request.messages) <= 12000 and sum(len(item.content) for item in request.messages) <= 24000)
        compact = json.dumps(body, ensure_ascii=False, separators=(",", ":"))
        bound = len(compact.encode("utf-8")) + 512
        reserve = (Decimal(bound) * Decimal(price["input_cache_miss"]) + Decimal(1500) * Decimal(price["output"])) / 1000000
        rows.append({"case_id": cid, "path": path, "input_ref": f"../20261022-r1/agent-input-templates/{cid}-input.json", "message_characters": sum(len(item.content) for item in request.messages), "maximum_message_characters": max(len(item.content) for item in request.messages), "whole_body_UTF8_bytes": len(compact.encode("utf-8")), "input_upper_tokens": bound, "max_output_tokens": 1500, "reservation_upper_cny": format(reserve, ".8f"), "budget_bound_includes_schema_and_all_payload_fields": True})
        if cid == "Q01":
            write("Q01-prepared-request-not-sent.json", body)
    check("zero_provider_calls", provider.calls == 0)
    for label, folder, filename in (("old_Q07", "20261024-flash-pro-r3", "Q07-response.json"), ("old_Q01", "20261024-flash-pro-r4", "Q01-response.json")):
        invalid = read(V2 / "S08-评价运行" / folder / "invalid-candidates" / filename)
        try:
            PracticeReviewDraft.model_validate(invalid["response"])
        except ValueError:
            check(label + "_still_invalid_no_repair", True)
        else:
            raise AssertionError(label + "_silently_repaired")
    write("wire-output-schema.json", wire)
    write("public-output-schema.json", PracticeReviewDraft.model_json_schema())
    (HERE / "review-role-instruction.txt").write_text(agent.role_instruction + "\n", encoding="utf-8")
    write("request-preflight.json", {"status": "passed", "requests_constructed": 16, "requests_sent": 0, "requests": rows})
    params = deepcopy(read(last / "parameters.json"))
    params["evaluation_id"] = "S08-responses-schema-r1-proposal-only"
    params["roles"]["under_test"].update(prompt_version=PRACTICE_REVIEW_PROMPT_VERSION, request_version=PRACTICE_REVIEW_REQUEST_VERSION, endpoint="/responses", response_format="json_schema", output_schema_ref="wire-output-schema.json", terminal_status="completed")
    params["roles"]["judge_formal"].update(endpoint="/chat/completions", response_format="json_object", terminal_status="stop")
    params["endpoint"] = "role_specific_see_roles"
    params["input_token_upper_method"] = "完整请求payload紧凑UTF8字节+512；须包括text.format.schema，不能只计messages"
    write("proposed-parameters.json", params)
    write("budget-plan.json", {"status": "proposal_only_not_authorized", "current_real_call_authorization": 0, "proposed_roles": {"under_test": 16, "judge_formal": 16, "judge_calibration": 0}, "proposed_total_calls": 32, "currency": "CNY", "proposed_hard_cap": "1.53061200", "prior_r2_and_continuations_spent_or_held": "0.46938800", "combined_original_cap": "2.00000000", "current_stopped_round_unused_calls": {"under_test": 15, "judge_formal": 16}, "additional_under_test_calls_needed_if_renewed": 1, "known_under_test_max_reservations_sum_cny": format(sum((Decimal(row["reservation_upper_cny"]) for row in rows), Decimal(0)), ".8f"), "judge_cost": "依赖新候选；实际完整payload生成后按角色逐次预留，J1仍旧Chat", "calibration": "只有J1精确模型/Chat协议/提示/参数/材料/服务指纹不变才复用旧Pro3/3，不满足停止另定范围", "under_test_service_fingerprint": "Responses文档未承诺返回Chat同名指纹，不伪造；真实兼容性/服务追溯须新范围明确", "unknown_usage": "保留预留并停止，不填0；不得把Schema400或无效响应当免费", "max_retries": 0, "automatic_chat_fallback": False, "full_round_under_cap_guaranteed": False, "student_code_execution": False, "database_access": False, "S09": False})
    write("local-checks.json", {"status": "passed", "checks_passed": len(checks), "checks": checks, "prompt_version": PRACTICE_REVIEW_PROMPT_VERSION, "request_version": PRACTICE_REVIEW_REQUEST_VERSION, "public_schema_version": PRACTICE_REVIEW_SCHEMA_VERSION, "wire_schema_characters": len(new_schema_text), "real_model_calls": 0, "provider_calls": provider.calls, "credentials_read": False, "database_access": False, "student_code_executed_or_compiled": False, "real_provider_compatibility": "not_run", "real_AI_quality": "not_accepted"})
    print(json.dumps({"status": "passed", "checks": len(checks), "requests": 16, "schema_characters": len(new_schema_text), "real_calls": 0, "maximum_request_chars": max(row["message_characters"] for row in rows)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

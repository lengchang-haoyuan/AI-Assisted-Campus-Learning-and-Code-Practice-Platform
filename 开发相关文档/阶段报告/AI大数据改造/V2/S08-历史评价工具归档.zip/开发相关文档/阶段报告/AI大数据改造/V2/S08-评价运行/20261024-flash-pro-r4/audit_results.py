"""离线审计：已观测usage与请求成败分开记账；不发模型或数据库请求。"""

from collections import Counter
from decimal import Decimal
import json
from pathlib import Path

from score_results_r3 import summarize

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def accounting_totals(ledger: dict, pricing: dict) -> dict:
    """失败仍保留已返回的tokens；缺失usage记未知，不把预留当实际扣款。"""
    tokens, role_known, role_held = Counter(), Counter(), Counter()
    unknown = []
    for row in ledger["attempts"]:
        held = Decimal(row["budget_charged_upper_cny"])
        role_held[row["role"]] += held
        retained = row["status"] != "response_received" or row["budget_basis"].startswith("full_reservation_retained")
        if retained and held != Decimal(row["reservation_upper_cny"]):
            raise ValueError("failed_attempt_reservation_mismatch")
        usage = row.get("raw_usage") or row.get("usage")
        if not isinstance(usage, dict) or not all(type(usage.get(key)) is int and usage[key] >= 0 for key in ("prompt_tokens", "completion_tokens", "total_tokens")):
            unknown.append(row["attempt_id"])
            continue
        if usage["prompt_tokens"] + usage["completion_tokens"] != usage["total_tokens"]:
            raise ValueError("observed_usage_total_mismatch")
        if row.get("usage") is not None and any(row["usage"].get(key) != usage[key] for key in ("prompt_tokens", "completion_tokens", "total_tokens")):
            raise ValueError("observed_usage_ledger_mismatch")
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            tokens[key] += usage[key]
        for key, raw_key in (("cache_hit_tokens", "prompt_cache_hit_tokens"), ("cache_miss_tokens", "prompt_cache_miss_tokens")):
            if type(usage.get(raw_key)) is int:
                tokens[key] += usage[raw_key]
        prices = pricing["models"][row["model_requested"]]["peak"]
        fee = (Decimal(usage["prompt_tokens"]) * Decimal(prices["input_cache_miss"]) + Decimal(usage["completion_tokens"]) * Decimal(prices["output"])) / Decimal(pricing["unit_tokens"])
        role_known[row["role"]] += fee
        if not retained and held != fee:
            raise ValueError("successful_usage_settlement_mismatch")
    return {
        "tokens": dict(tokens), "unknown_usage_attempts": unknown,
        "known_usage_peak_upper_cny": format(sum(role_known.values(), Decimal(0)), ".8f"),
        "spent_or_held_upper_cny": format(sum(role_held.values(), Decimal(0)), ".8f"),
        "known_usage_by_role": {key: format(value, ".8f") for key, value in role_known.items()},
        "spent_or_held_by_role": {key: format(value, ".8f") for key, value in role_held.items()},
        "account_charge_verified": False,
    }


def audit(run_dir: Path = HERE) -> dict:
    ledger, auth, pricing = (read(run_dir / name) for name in ("ledger.json", "authorization.json", "pricing-basis.json"))
    checks = []

    def check(name, condition):
        checks.append({"name": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)

    check("round_finished", ledger["status"] != "running")
    counts = Counter(row["role"] for row in ledger["attempts"])
    check("new_role_and_total_caps", len(ledger["attempts"]) == ledger["provider_attempts"] <= auth["total_provider_attempt_limit"] and all(counts[role] == ledger["role_usage"][role] <= limit for role, limit in auth["role_limits"].items()))
    check("no_retry_or_new_calibration", ledger["max_retries"] == ledger["transport_retries"] == counts["judge_calibration"] == 0)
    check("calibration_reused", ledger["calibration_passed"] and ledger["calibration_reused"])
    for row in ledger["attempts"]:
        aid = row["attempt_id"]
        if not row.get("raw_request_ref"):
            check(aid + "_failure_before_post", row["http_request_events"] == 0 and row["status"] != "response_received")
            continue
        request = read(run_dir / row["raw_request_ref"])
        check(aid + "_single_post_and_parameters", row["http_request_events"] == 1 and request["model"] == row["model_requested"] and request["temperature"] == 0 and request["max_tokens"] == row["output_cap"] and request["stream"] is False and request["thinking"] == {"type": "disabled"} and request["response_format"] == {"type": "json_object"} and "headers" not in request)
        bound = len(json.dumps(request["messages"], ensure_ascii=False, separators=(",", ":")).encode("utf-8")) + 512
        prices = pricing["models"][request["model"]]["peak"]
        reserve = (Decimal(bound) * Decimal(prices["input_cache_miss"]) + Decimal(request["max_tokens"]) * Decimal(prices["output"])) / Decimal(pricing["unit_tokens"])
        check(aid + "_reservation", bound == row["input_upper_tokens"] and reserve == Decimal(row["reservation_upper_cny"]))
        if not row.get("raw_response_ref"):
            check(aid + "_unknown_response_retained", row["status"] != "response_received")
            continue
        response = read(run_dir / row["raw_response_ref"])
        if response.get("usage") is not None:
            check(aid + "_raw_usage_retained_even_on_failure", row.get("raw_usage") == response["usage"])
        if row["status"] != "response_received":
            continue
        provider = read(run_dir / row["provider_result_ref"])
        check(aid + "_normal_response", row["http_status"] == 200 and response["choices"][0]["finish_reason"] == "stop" and response["model"] == request["model"] == provider["model"])
        check(aid + "_provider_content", provider["content"] == response["choices"][0]["message"]["content"].strip())
        check(aid + "_provider_usage", all(response["usage"][key] == row["usage"][key] == provider["usage"][key] for key in ("prompt_tokens", "completion_tokens", "total_tokens")))
        cid = row["input_id"]
        kind = "judges" if row["role"] == "judge_formal" else "candidates"
        envelope = read(run_dir / kind / f"{cid}-response.json")
        check(aid + "_result_matches_raw", envelope["response"] == json.loads(response["choices"][0]["message"]["content"]))
        if row["role"] == "judge_formal":
            check(aid + "_calibrated_fingerprint", response.get("system_fingerprint") == auth["judge_calibration_system_fingerprint"])
            check(aid + "_judge_input_actual", json.loads(request["messages"][1]["content"]) == read(run_dir / "judges" / f"{cid}-input.json"))
    totals = accounting_totals(ledger, pricing)
    held = Decimal(totals["spent_or_held_upper_cny"])
    check("held_matches_ledger_and_new_cap", held == Decimal(ledger["conservative_spend_or_held_upper_cny"]) <= Decimal(auth["currency_hard_cap"]))
    check("combined_original_cap", held + Decimal(auth["previous_spent_or_held_upper_cny"]) <= Decimal(auth["combined_currency_hard_cap"]))
    check("remaining_money", Decimal(ledger["remaining_hard_cap_upper_cny"]) == Decimal(auth["currency_hard_cap"]) - held)
    check("observed_tokens_include_failed_rows", totals["tokens"].get("prompt_tokens", 0) == ledger["total_prompt_tokens_recorded"] and totals["tokens"].get("completion_tokens", 0) == ledger["total_completion_tokens_recorded"])
    replay = summarize(run_dir / "candidates", run_dir / "judges", run_dir=run_dir)
    if ledger["status"].startswith("completed_"):
        check("all16_not_reduced_denominator", ledger["completed_case_ids"] == [f"Q{i:02}" for i in range(1, 17)] and counts["under_test"] == counts["judge_formal"] == 16)
        check("scoring_replay", replay == read(run_dir / "rule-summary.json"))
        check("quality_matches_complete_rules", ledger["S08_fixed_case_quality_passed"] == (replay["all_rule_gates_pass"] and ledger["calibration_passed"]))
    else:
        check("partial_not_complete", not ledger["S08_fixed_case_quality_passed"] and replay["status"] == "not_completed" and replay["quality_metrics"] is None)
    return {"audit_status": "passed", "evaluation_status": ledger["status"], "assertions": len(checks), "checks": checks, "new_calls": ledger["provider_attempts"], "new_role_usage": ledger["role_usage"], "reused_candidate_judge_pairs": 0, "new_accounting": totals, "combined_spent_or_held_upper_cny": format(held + Decimal(auth["previous_spent_or_held_upper_cny"]), ".8f"), "quality_metrics": replay.get("quality_metrics"), "rule_gates": replay.get("rule_gates"), "quality_passed": ledger["S08_fixed_case_quality_passed"], "audit_side_effects": {"model_calls": 0, "database_access": False, "credentials_read": False, "student_code_executed": False}}


if __name__ == "__main__":
    result = audit()
    (HERE / "result-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("audit_status", "assertions", "new_calls", "combined_spent_or_held_upper_cny", "quality_passed")}, ensure_ascii=False))

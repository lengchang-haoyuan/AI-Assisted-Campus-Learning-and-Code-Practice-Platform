"""纯计分器合成边界自检；临时夹具不是模型输出或质量证据。"""

import json
from pathlib import Path
from tempfile import gettempdir, TemporaryDirectory

from score_results import HERE, V2, load, summarize


def save(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def write_synthetic_fixtures(candidate_dir: Path, judge_dir: Path) -> None:
    """仅构造结构自检夹具；无代码执行、Provider请求或保留的原始响应。"""
    contract = load(V2 / "S01-AI固定模板与评价案例.json")
    marker = "纯计分器合成夹具，不是模型输出或质量证据"
    for case in contract["cases"]:
        cid = case["case_id"]
        issue_types = {item["criterion_id"]: item["issue_type"] for item in case["reference_issues"]}
        code = case["student_code"] or ""
        snippet = next((line for line in code.splitlines() if line.strip()), None)
        criteria = []
        for criterion_id, verdict in case["reference_criteria"].items():
            criteria.append({
                "criterion_id": criterion_id, "verdict": verdict,
                "issue_type": issue_types.get(criterion_id) if verdict == "fail" else None,
                "evidence_span": snippet if verdict == "fail" else None,
                "reason": marker,
                "suggested_self_test": "合成结构占位，不执行任何代码" if verdict == "fail" else None,
                "next_action": "合成结构占位，等待补充材料或修正" if verdict in {"fail", "unknown"} else None,
            })
        response = {"summary": marker, "overall": case["reference_label"], "criteria": criteria}
        artifact_id = f"S08-{cid}-candidate-v1"
        save(candidate_dir / f"{cid}-response.json", {"case_id": cid, "artifact_id": artifact_id, "text_version": "1.0", "response": response, "fixture_scope": marker})
        judge_input = load(HERE / f"judge-input-templates/{cid}-input.json")
        judge_input["data"]["candidate_feedback"] = json.dumps(response, ensure_ascii=False, indent=2)
        save(judge_dir / f"{cid}-input.json", judge_input)
        judge_response = {
            "case_id": cid, "status": "scored",
            "criterion_evidence": [{"criterion_id": criterion_id, "evidence_valid": True, "quote": marker, "reason": marker} for criterion_id in case["reference_criteria"]],
            "actionability_score": 3, "unsupported_claim": False, "reason": marker,
        }
        save(judge_dir / f"{cid}-response.json", {"case_id": cid, "candidate_artifact_id": artifact_id, "candidate_text_version": "1.0", "response": judge_response, "fixture_scope": marker})


def change_q05_evidence(judge_dir: Path, value: bool | None) -> None:
    path = judge_dir / "Q05-response.json"
    envelope = load(path)
    row = next(item for item in envelope["response"]["criterion_evidence"] if item["criterion_id"] == "C01")
    row["evidence_valid"] = value
    save(path, envelope)


def check_boundaries() -> dict:
    checks = []

    def check(name: str, condition: bool) -> None:
        checks.append({"check": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)

    temporary_root = Path(gettempdir()).resolve()
    with TemporaryDirectory(prefix="s08-scorer-unit-", dir=temporary_root) as temporary:
        work = Path(temporary).resolve()
        if work.parent != temporary_root or not work.name.startswith("s08-scorer-unit-"):
            raise RuntimeError("unexpected_temporary_fixture_target")
        candidates, judges = work / "synthetic-candidates", work / "synthetic-judges"
        candidates.mkdir()
        judges.mkdir()
        write_synthetic_fixtures(candidates, judges)
        positive = summarize(candidates, judges)
        check("synthetic_positive_control_rule_gates", positive.get("all_rule_gates_pass") is True)
        change_q05_evidence(judges, False)
        unsupported = summarize(candidates, judges)
        metrics = unsupported["quality_metrics"]
        check("false_evidence_TP8", metrics["TP"] == 8)
        check("false_evidence_FN1", metrics["FN"] == 1)
        check("false_evidence_cell_recorded", metrics["unsupported_issue_cells"] == 1)
        check("top_level_false_does_not_mask_cell", metrics["unsupported_claims"] == 0)
        check("unsupported_gate_fails", unsupported["rule_gates"]["unsupported_definitive_claims"] is False)
        check("TP8_FN1_cannot_pass_all_gates", unsupported["all_rule_gates_pass"] is False)
        check("issue_denominator_stays9", metrics["recall"] == "8/9")
        check("correct_denominator_stays69", metrics["false_positive_rate"] == "0/69")
        change_q05_evidence(judges, None)
        unresolved = summarize(candidates, judges)
        check("null_evidence_not_completed", unresolved["status"] == "not_completed")
        check("null_evidence_cannot_pass", unresolved["all_rule_gates_pass"] is False)
        check("null_evidence_no_forced_metrics", unresolved["quality_metrics"] is None)
        check("null_evidence_cell_retained", unresolved["observed_issue_cell_flags"]["unresolved_issue_cells"] == 1)
        check("null_keeps_issue_denominator9", unresolved["frozen_denominators"]["reference_issue_cells"] == 9)
        check("null_keeps_correct_denominator69", unresolved["frozen_denominators"]["known_pass_cells"] == 69)
    return {
        "status": "passed", "scope": "synthetic_scoring_utility_test_only_not_model_quality_or_raw_model_response",
        "assertions": len(checks), "passed": sum(row["passed"] for row in checks),
        "checks": checks,
        "false_evidence_boundary": {"TP": metrics["TP"], "FN": metrics["FN"], "unsupported_claims_top_level": metrics["unsupported_claims"], "unsupported_issue_cells": metrics["unsupported_issue_cells"], "all_rule_gates_pass": unsupported["all_rule_gates_pass"]},
        "null_evidence_boundary": {"status": unresolved["status"], "unresolved_issue_cells": unresolved["observed_issue_cell_flags"]["unresolved_issue_cells"], "quality_metrics": unresolved["quality_metrics"], "frozen_denominators": unresolved["frozen_denominators"]},
        "temporary_synthetic_fixtures_retained": False, "model_calls": 0,
        "database_access": False, "student_code_executed": False,
    }


if __name__ == "__main__":
    print(json.dumps(check_boundaries(), ensure_ascii=True, indent=2))

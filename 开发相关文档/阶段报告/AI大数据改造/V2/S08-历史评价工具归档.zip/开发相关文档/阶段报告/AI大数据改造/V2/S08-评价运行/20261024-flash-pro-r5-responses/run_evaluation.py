"""S08单轮静态评价；默认零网络预检，仅root审阅后--execute，已有账本不重跑。"""

import argparse
import asyncio
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
import os
from pathlib import Path
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
V2 = HERE.parent.parent
PREP = V2 / "S08-评价准备/20261022-r1"
ROOT = next(parent for parent in HERE.parents if (parent / "backend").is_dir())
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(PREP))
sys.path.insert(0, str(HERE))

import httpx

from app.ai.client import AIClient
from app.ai.deepseek import DeepSeekProvider
from app.ai.provider import (
    AIClientError, AICompletionRequest, AIMessage, AIMessageRole, AIProvider,
    AIResponseFormat,
)
from app.context.context_schema import ContextSource, ContextSourceType
from app.context.project_context import ContextBuilder, ProjectContext, ProjectContextSeed
from app.models.enums import ProjectDifficulty
from app.practice.agent import PRACTICE_CONTEXT_FIELDS
from app.practice.review import (PracticeReviewAgent, PracticeReviewDraft, PRACTICE_REVIEW_PROMPT_VERSION, PRACTICE_REVIEW_REQUEST_VERSION, PRACTICE_REVIEW_SCHEMA_VERSION)
from score_results_r3 import summarize
from validate_judge import validate_feedback

CASE_IDS = tuple(f"Q{index:02}" for index in range(1, 17))
CALIBRATION_IDS = ("G01", "G02", "G03")
ROLE_LIMITS = {"under_test": 16, "judge_calibration": 0, "judge_formal": 16}
CAP = Decimal("1.53061200")
PREVIOUS_HELD = Decimal("0.46938800")


class StopRound(RuntimeError):
    """只含固定错误码；不得放入响应正文、配置或凭证。"""


def require(condition: bool, code: str) -> None:
    if not condition:
        raise StopRound(code)


def now() -> str:
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path: Path, value: object) -> None:
    """所有输出限制在本轮目录，账本替换完成后才允许发请求。"""
    require(path.resolve().is_relative_to(HERE), "write_outside_run_directory")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def money(value: Decimal) -> str:
    return format(value, ".8f")


def payload_for(request: AICompletionRequest) -> dict:
    return DeepSeekProvider._request_payload(request)[1]


def input_upper_tokens(request: AICompletionRequest, margin: int) -> int:
    # 包括text.format.schema；与实际Provider统一payload，不只数messages。
    body = json.dumps(payload_for(request), ensure_ascii=False, separators=(",", ":"))
    return len(body.encode("utf-8")) + margin


def observed_usage(raw_usage: object, role: str) -> dict | None:
    if not isinstance(raw_usage, dict):
        return None
    source = ("input_tokens", "output_tokens", "total_tokens") if role == "under_test" else ("prompt_tokens", "completion_tokens", "total_tokens")
    values = [raw_usage.get(key) for key in source]
    if not all(type(value) is int and value >= 0 for value in values) or values[0] + values[1] != values[2]:
        return None
    return dict(zip(("prompt_tokens", "completion_tokens", "total_tokens"), values))


def priced_upper(input_tokens: int, output_tokens: int, model: str, pricing: dict) -> Decimal:
    prices = pricing["models"][model]["peak"]
    return (Decimal(input_tokens) * Decimal(prices["input_cache_miss"]) + Decimal(output_tokens) * Decimal(prices["output"])) / Decimal(pricing["unit_tokens"])


def new_context() -> ProjectContext:
    return ContextBuilder().build(
        ProjectContextSeed(
            project_name="S08固定CSV静态评价", language="Python", framework=None,
            frontend=None, backend=None, database=None, difficulty=ProjectDifficulty.BEGINNER,
            requirements=[{"title": "固定Python CSV函数静态评审"}],
            output_requirement="只静态评审输入中的固定任务与验收项，不执行学生代码。",
        ),
        source=ContextSource(type=ContextSourceType.PROJECT, id=1),
        now=datetime(2026, 10, 22, tzinfo=timezone.utc),
    )


class NoNetworkProvider(AIProvider):
    @property
    def name(self) -> str:
        return "preflight_no_network"

    async def complete(self, request: AICompletionRequest):
        del request
        raise StopRound("preflight_must_not_call_provider")


def ai_client(provider: AIProvider, params: dict) -> AIClient:
    return AIClient(
        provider, total_timeout_seconds=params["total_timeout_seconds"], max_retries=0,
        retry_base_delay_seconds=0, max_retry_delay_seconds=0,
    )


def review_agent(client: AIClient, params: dict) -> PracticeReviewAgent:
    role = params["roles"]["under_test"]
    return PracticeReviewAgent(client, model=role["model_id"], max_tokens=role["max_tokens"], temperature=params["temperature"])


def review_request(agent: PracticeReviewAgent, context: ProjectContext, input_data: dict, params: dict) -> AICompletionRequest:
    del params
    return agent._build_completion_request(context, agent.validate_input(input_data), context_fields=PRACTICE_CONTEXT_FIELDS)


def judge_request(input_obj: dict, role: str, params: dict) -> AICompletionRequest:
    return AICompletionRequest(
        messages=(
            AIMessage(role=AIMessageRole.SYSTEM, content=(PREP / "judge-r4-system.txt").read_text(encoding="utf-8")),
            AIMessage(role=AIMessageRole.USER, content=json.dumps(input_obj, ensure_ascii=False, separators=(",", ":"))),
        ),
        model=params["roles"][role]["model_id"], temperature=params["temperature"],
        max_tokens=1200, response_format=AIResponseFormat.JSON_OBJECT, reasoning_enabled=False,
    )


def require_judge_fingerprint(role: str, raw: dict, auth: dict) -> None:
    if role == "judge_formal":
        require(raw.get("system_fingerprint") == auth["judge_calibration_system_fingerprint"], "judge_service_fingerprint_changed_calibration_not_reusable")


def verify_calibration_reuse(auth: dict, params: dict) -> dict:
    previous_dir = V2 / "S08-评价运行/20261022-flash-pro-r1"
    previous = read(previous_dir / "ledger.json")
    previous_params = read(previous_dir / "parameters.json")
    require(previous["calibration_passed"] and previous["calibration_model_id"] == "deepseek-v4-pro", "prior_pro_calibration_not_valid")
    require(all(all(params["roles"][role].get(key) == value for key, value in previous_params["roles"][role].items()) for role in ("judge_calibration", "judge_formal")), "judge_role_parameters_changed")
    common = ("provider", "base_url", "temperature", "reasoning_enabled", "thinking", "connect_timeout_seconds", "request_timeout_seconds", "total_timeout_seconds", "max_retries", "transport_retries", "stream", "follow_redirects")
    require(all(params[key] == previous_params[key] for key in common), "judge_common_parameters_changed")
    expected_cases = read(PREP / "calibration-expected.json")["cases"]
    judge_prompt = (PREP / "judge-r4-system.txt").read_text(encoding="utf-8").strip()
    cal_rows = []
    for case_id in CALIBRATION_IDS:
        rows = [row for row in previous["attempts"] if row["role"] == "judge_calibration" and row["input_id"] == case_id]
        require(len(rows) == 1, "prior_calibration_row_count_changed")
        row = rows[0]
        raw_request = read(previous_dir / row["raw_request_ref"])
        raw_response = read(previous_dir / row["raw_response_ref"])
        input_obj = read(PREP / f"calibration-inputs/{case_id}-input.json")
        require(raw_request["messages"][0]["content"] == judge_prompt and json.loads(raw_request["messages"][1]["content"]) == input_obj, "calibration_material_or_prompt_changed")
        require(payload_for(judge_request(input_obj, "judge_calibration", params)) == raw_request, "calibration_exact_wire_parameters_changed")
        require(raw_response.get("model") == "deepseek-v4-pro", "calibration_model_changed")
        require(raw_response.get("system_fingerprint") == auth["judge_calibration_system_fingerprint"], "calibration_fingerprint_changed")
        expected = next(value for value in expected_cases if value["calibration_id"] == case_id)
        response = read(previous_dir / f"calibration/{case_id}-response.json")
        require(json.loads(raw_response["choices"][0]["message"]["content"]) == response, "calibration_saved_response_differs_from_raw")
        validation = validate_feedback(input_obj, response, expected)
        require(validation["calibration_pass"], "reused_calibration_expected_mismatch_" + case_id)
        cal_rows.append({"calibration_id": case_id, "source_response_ref": f"../20261022-flash-pro-r1/{row['raw_response_ref']}", "source_validation_ref": f"../20261022-flash-pro-r1/validations/{case_id}.json", "current_local_validation": validation})
    return {"status": "reused_pro_calibration_3_of_3_materials_valid", "source_ledger_ref": "../20261022-flash-pro-r1/ledger.json", "model_id": "deepseek-v4-pro", "prompt_version": "judge-r4", "expected_system_fingerprint": auth["judge_calibration_system_fingerprint"], "calibration_calls_this_round": 0, "all_new_formal_responses_require_same_fingerprint": True, "cases": cal_rows}


def preflight() -> tuple[dict, dict, dict, dict, dict]:
    """仅本地核对；不构造AISettings、读取key或请求模型/数据库。"""
    auth, params, pricing = (read(HERE / filename) for filename in ("authorization.json", "parameters.json", "pricing-basis.json"))
    require(auth["role_limits"] == ROLE_LIMITS and auth["total_provider_attempt_limit"] == 32, "authorization_role_limits_changed")
    require(auth.get("authorized") in (True, False), "authorization_state_missing")
    prior_r2 = read(HERE.parent / "20261023-flash-pro-r2/ledger.json")
    prior_r3 = read(HERE.parent / "20261024-flash-pro-r3/ledger.json")
    prior_r4 = read(HERE.parent / "20261024-flash-pro-r4/ledger.json")
    require(prior_r2["status"] == prior_r3["status"] == prior_r4["status"] == "stopped", "prior_round_state_changed")
    require(sum((Decimal(row["conservative_spend_or_held_upper_cny"]) for row in (prior_r2, prior_r3, prior_r4)), Decimal(0)) == PREVIOUS_HELD == Decimal(auth["previous_spent_or_held_upper_cny"]), "previous_budget_basis_changed")
    require(CAP + PREVIOUS_HELD == Decimal(auth["combined_currency_hard_cap"]) == Decimal("2.00"), "combined_original_cap_changed")
    require(read(HERE / "frozen-reference-contract.json") == read(V2 / "S01-AI固定模板与评价案例.json"), "frozen_reference_changed")
    require(auth["currency"] == "CNY" and Decimal(auth["currency_hard_cap"]) == CAP, "authorization_currency_cap_changed")
    require(auth["under_test_exact_model_id"] == "deepseek-flash" and auth["judge_exact_model_id"] == "deepseek-v4-pro", "authorization_model_changed")
    require(auth["new_judge_calibration_required"] is False and auth["calibration_reuse_from_S08_r1"] is True and auth["calibration_reuse_from_S06"] is False, "reused_pro_calibration_only")
    require(params["provider"] == "deepseek" and params["base_url"] == "https://api.deepseek.com" and params["endpoint"] == "role_specific_see_roles", "provider_target_changed")
    require(params["temperature"] == 0 and params["reasoning_enabled"] is False and params["thinking"] == {"type": "disabled"}, "sampling_parameters_changed")
    require(params["max_retries"] == params["transport_retries"] == 0 and params["request_protocol_token_margin"] == 512, "retry_or_budget_margin_changed")
    require(params["total_timeout_seconds"] == params["request_timeout_seconds"] == 60 and params["connect_timeout_seconds"] == 5, "timeouts_changed")
    require(params["response_format"] == "role_specific_see_roles" and params["stream"] is False and params["follow_redirects"] is False, "response_or_redirect_policy_changed")
    require(params["roles"]["under_test"]["model_id"] == "deepseek-flash" and params["roles"]["under_test"]["max_tokens"] == 1500, "under_test_parameters_changed")
    require(params["roles"]["under_test"]["prompt_version"] == PRACTICE_REVIEW_PROMPT_VERSION == "practice-review-r4" and PRACTICE_REVIEW_SCHEMA_VERSION == "practice-review/1.0", "current_review_version_changed")
    require(params["roles"]["under_test"]["request_version"] == PRACTICE_REVIEW_REQUEST_VERSION == "practice-review-responses-schema-r1", "request_protocol_version_changed")
    require(params["roles"]["under_test"]["endpoint"] == "/responses" and params["roles"]["under_test"]["response_format"] == "json_schema", "under_test_native_schema_required")
    require(all(params["roles"][role]["endpoint"] == "/chat/completions" and params["roles"][role]["response_format"] == "json_object" for role in ("judge_formal", "judge_calibration")), "judge_chat_protocol_required")
    require((HERE / "review-role-instruction.txt").read_text(encoding="utf-8") == PracticeReviewAgent.role_instruction + "\n", "frozen_review_r2_role_changed")
    require(read(HERE / "review-draft-schema.json") == PracticeReviewDraft.model_json_schema(), "review_schema_changed")
    require(read(HERE / "wire-output-schema.json") == PracticeReviewAgent._model_output_json_schema(review_agent(ai_client(NoNetworkProvider(), params), params)), "wire_schema_changed")
    require(all(params["roles"][role]["model_id"] == "deepseek-v4-pro" and params["roles"][role]["max_tokens"] == 1200 for role in ("judge_calibration", "judge_formal")), "judge_parameters_changed")
    require(pricing["currency"] == "CNY" and pricing["unit_tokens"] == 1000000, "pricing_unit_changed")
    require(pricing["models"]["deepseek-flash"]["peak"] == {"input_cache_hit": "0.04", "input_cache_miss": "2", "output": "8"}, "flash_peak_price_changed")
    require(pricing["models"]["deepseek-v4-pro"]["peak"] == {"input_cache_hit": "0.30", "input_cache_miss": "9", "output": "27"}, "pro_peak_price_changed")
    require(params["roles"]["judge_formal"]["documented_service_version"] == pricing["models"]["deepseek-v4-pro"]["documented_service_version"] == "DeepSeek-V4-Pro-0813", "documented_judge_service_version_changed")
    reuse = verify_calibration_reuse(auth, params)
    write(HERE / "calibration-reuse.json", reuse)
    contract = read(V2 / "S01-AI固定模板与评价案例.json")
    require(tuple(case["case_id"] for case in contract["cases"]) == CASE_IDS, "case_order_changed")
    previous_dir = V2 / "S08-评价运行/20261022-flash-pro-r1"
    previous = read(previous_dir / "ledger.json")
    previous_role = (PREP / "review-role-instruction.txt").read_text(encoding="utf-8").removesuffix("\n")
    old_schema_text = json.dumps(read(PREP / "review-draft-schema.json"), ensure_ascii=False, separators=(",", ":"))
    new_schema_text = json.dumps(read(HERE / "wire-output-schema.json"), ensure_ascii=False, separators=(",", ":"))
    context = new_context()
    require(context.to_storage() == read(previous_dir / "fixed-context.json"), "fixed_context_changed")
    prepared_requests, costs = {}, []
    agent = review_agent(ai_client(NoNetworkProvider(), params), params)
    for case in contract["cases"]:
        case_id = case["case_id"]
        input_data = read(PREP / f"agent-input-templates/{case_id}-input.json")
        require(input_data["code"] == case["student_code"] and input_data["self_statement"] == case["self_statement"], "fixed_code_or_statement_changed_" + case_id)
        request = review_request(agent, context, input_data, params)
        prepared_requests[case_id] = request
        old_attempt = next(row for row in previous["attempts"] if row["role"] == "under_test" and row["input_id"] == case_id)
        old_payload = read(previous_dir / old_attempt["raw_request_ref"])
        body = payload_for(request)
        require(DeepSeekProvider._request_payload(request)[0] == "/responses", "native_schema_endpoint_required")
        require(body["input"][1:] == old_payload["messages"][1:], "fixed_data_messages_changed_" + case_id)
        expected_system = old_payload["messages"][0]["content"].replace(previous_role, PracticeReviewAgent.role_instruction, 1).replace(old_schema_text, new_schema_text, 1)
        require(body["input"][0] == {"role": "system", "content": expected_system}, "request_changed_beyond_frozen_role_and_schema_" + case_id)
        require(body["text"]["format"]["schema"] == read(HERE / "wire-output-schema.json") and body["reasoning"] == {"effort": "none"} and body["max_output_tokens"] == 1500, "native_schema_wire_parameters_changed")
        bound = input_upper_tokens(request, 512)
        costs.append({"role": "under_test", "input_id": case_id, "input_upper_tokens": bound, "output_cap": 1500, "reservation_upper_cny": money(priced_upper(bound, 1500, request.model, pricing))})
    require(all(Decimal(row["reservation_upper_cny"]) <= CAP for row in costs), "single_request_reservation_exceeds_hard_cap")
    prior_tools = HERE.parent / "20261024-flash-pro-r4"
    expected_score = (prior_tools / "score_results_r3.py").read_text(encoding="utf-8").replace('{"practice-review-r1", "practice-review-r2", "practice-review-r3"}', '{"practice-review-r1", "practice-review-r2", "practice-review-r3", "practice-review-r4"}', 1).replace('"practice-review-r3": ("v3", "3.0")}', '"practice-review-r3": ("v3", "3.0"), "practice-review-r4": ("v4", "4.0")}', 1)
    require((HERE / "score_results_r3.py").read_text(encoding="utf-8") == expected_score, "scoring_changed_beyond_new_prompt_binding")
    require((HERE / "validate_judge.py").read_bytes() == (prior_tools / "validate_judge.py").read_bytes(), "evaluation_method_r3_quote_validator_changed")
    require((HERE / "frozen_review_schema.py").read_bytes() == (prior_tools / "frozen_review_schema.py").read_bytes(), "frozen_output_schema_changed")
    report = {"status": "preflight_passed", "checked_at": now(), "evaluation_id": auth["evaluation_id"], "credentials_read": False, "network_requests": 0, "database_access": False, "student_code_executed": False, "existing_ledger": (HERE / "ledger.json").exists(), "currency_hard_cap_cny": money(CAP), "role_limits": ROLE_LIMITS, "reused_pro_calibration": "3/3", "calibration_reuse_ref": "calibration-reuse.json", "new_calibration_calls": 0, "under_test_requests_checked": 16, "only_frozen_role_and_native_schema_change": True, "authorization_valid": auth["authorized"], "role_protocols": {"under_test": "/responses", "judge_formal": "/chat/completions"}, "scoring_algorithm_thresholds_unchanged": True, "known_request_reservations": costs, "sum_of_known_max_reservations_cny_not_a_charge": money(sum((Decimal(row["reservation_upper_cny"]) for row in costs), Decimal(0))), "formal_judge_cost": "candidate-dependent; recompute complete payload byte bound before each POST", "full_round_cost_guaranteed": False, "admission_rule": "spent_or_held_upper + next_request_reservation <= 1.530612 CNY; prior 0.469388 retained and combined <= 2 CNY; otherwise stop before POST", "failure_settlement": "full pre-POST reservation retained; call counted; stop", "execution": "not_run_use_explicit_execute_after_root_review"}
    return auth, params, pricing, prepared_requests, report


class Round:
    def __init__(self, auth: dict, params: dict, pricing: dict) -> None:
        self.auth, self.params, self.pricing = auth, params, pricing
        self.secret = ""
        self.active = None
        self.expected_payload = None
        self.captured = {}
        self.ledger = {
            "evaluation_id": auth["evaluation_id"], "status": "running", "started_at": now(),
            "evaluation_method_version": "evaluation-method-r3", "under_test_prompt_version": "practice-review-r4",
            "authorization_ref": "authorization.json", "parameters_ref": "parameters.json", "pricing_ref": "pricing-basis.json",
            "currency": "CNY", "currency_hard_cap": money(CAP), "conservative_spend_or_held_upper_cny": money(Decimal(0)),
            "provider_attempts": 0, "authorized_provider_attempts": 32,
            "role_usage": {role: 0 for role in ROLE_LIMITS}, "role_limits": ROLE_LIMITS,
            "calibration_passed": True, "calibration_reused": True, "calibration_model_id": "deepseek-v4-pro", "calibration_reuse_ref": "calibration-reuse.json", "calibration_source_ledger_ref": "../20261022-flash-pro-r1/ledger.json",
            "completed_case_ids": [], "attempts": [], "max_retries": 0, "transport_retries": 0,
            "account_reconciled": False, "account_balance_queried": False, "recharge_performed": False,
            "S08_fixed_case_quality_passed": False, "under_test_request_version": "practice-review-responses-schema-r1",
            "service_identity_policy": auth["under_test_service_identity_policy"],
        }

    def save(self) -> None:
        self.ledger["conservative_spend_or_held_upper_cny"] = money(sum((Decimal(row["budget_charged_upper_cny"]) for row in self.ledger["attempts"]), Decimal(0)))
        self.ledger["remaining_hard_cap_upper_cny"] = money(CAP - Decimal(self.ledger["conservative_spend_or_held_upper_cny"]))
        self.ledger["combined_spent_or_held_upper_cny"] = money(PREVIOUS_HELD + Decimal(self.ledger["conservative_spend_or_held_upper_cny"]))
        write(HERE / "ledger.json", self.ledger)

    def start_exclusive(self) -> None:
        require(not (HERE / "raw").exists(), "existing_raw_directory_requires_read_only_recovery")
        path = HERE / "ledger.json"
        # x模式也防止同时启动两个执行进程；已有0次账本亦交root只读确认，不自恢复。
        with path.open("x", encoding="utf-8") as stream:
            json.dump(self.ledger, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        (HERE / "raw").mkdir(exist_ok=False)
        self.save()

    async def capture_request(self, request: httpx.Request) -> None:
        require(self.active is not None, "unreserved_http_request_rejected")
        require(request.method == "POST" and str(request.url) == "https://api.deepseek.com" + self.active["endpoint"], "unexpected_http_target_rejected")
        require(self.active["http_request_events"] == 0, "second_http_request_rejected")
        body = request.content.decode("utf-8")
        require(self.secret not in body, "credential_in_request_body_rejected")
        payload = json.loads(body)
        require(payload == self.expected_payload, "actual_request_differs_from_reserved_request")
        self.active["http_request_events"] = 1
        self.active["raw_request_ref"] = f"raw/{self.active['attempt_id']}-request.json"
        write(HERE / self.active["raw_request_ref"], payload)  # 绝不保存请求headers。
        self.save()  # 计次/金额预留和原请求都已落盘，hook返回后才会POST。

    async def capture_response(self, response: httpx.Response) -> None:
        require(self.active is not None, "unbound_http_response")
        body = (await response.aread()).decode("utf-8", errors="replace")
        redacted = self.secret in body
        safe_body = body.replace(self.secret, "[REDACTED]") if redacted else body
        path = HERE / "raw" / f"{self.active['attempt_id']}-response.json"
        require(path.resolve().is_relative_to(HERE), "response_path_outside_run_directory")
        path.write_text(safe_body, encoding="utf-8")  # 仅body；没有headers、Token或账户查询。
        self.active.update(http_status=response.status_code, raw_response_ref=path.relative_to(HERE).as_posix(), response_redacted=redacted)
        try:
            self.captured[self.active["attempt_id"]] = json.loads(safe_body)
        except ValueError:
            self.captured[self.active["attempt_id"]] = {}
        self.save()
        require(not redacted, "credential_redacted_in_upstream_body_stop")

    async def invoke(self, role: str, input_id: str, request: AICompletionRequest, operation):
        require(self.ledger["role_usage"][role] < ROLE_LIMITS[role] and self.ledger["provider_attempts"] < 32, "role_or_total_call_limit_reached")
        require(input_id in CASE_IDS, "case_outside_fixed_scope_rejected")
        bound = input_upper_tokens(request, self.params["request_protocol_token_margin"])
        reservation = priced_upper(bound, request.max_tokens, request.model, self.pricing)
        consumed = Decimal(self.ledger["conservative_spend_or_held_upper_cny"])
        require(consumed + reservation <= CAP, "currency_hard_cap_next_reservation_rejected_before_POST")
        index = self.ledger["provider_attempts"] + 1
        attempt = {
            "attempt_no": index, "attempt_id": f"{index:02}-{role}-{input_id}", "role": role, "input_id": input_id,
            "status": "reserved_before_provider", "started_at": now(), "model_requested": request.model,
            "input_upper_tokens": bound, "output_cap": request.max_tokens,
            "reservation_upper_cny": money(reservation), "budget_charged_upper_cny": money(reservation),
            "budget_basis": "reservation_held_before_POST", "http_request_events": 0,
            "raw_request_ref": None, "raw_response_ref": None,
            "endpoint": DeepSeekProvider._request_payload(request)[0], "response_format": request.response_format.value,
            "expected_terminal_status": "completed" if role == "under_test" else "stop",
        }
        self.active, self.expected_payload = attempt, payload_for(request)
        self.ledger["attempts"].append(attempt)
        self.ledger["role_usage"][role] += 1
        self.ledger["provider_attempts"] += 1
        self.save()  # Provider失败亦不退回次数或预留。
        started = perf_counter()
        succeeded = False
        value = None
        try:
            value = await operation()
            completion = value.completion if hasattr(value, "completion") else value
            require(attempt["http_request_events"] == 1 and attempt["raw_response_ref"] is not None, "exactly_one_request_response_required")
            require(completion.model == request.model, "returned_model_identity_mismatch")
            require(completion.finish_reason == attempt["expected_terminal_status"], "unexpected_protocol_terminal_status")
            usage = completion.usage.model_dump(mode="json")
            require(all(type(usage.get(key)) is int and usage[key] >= 0 for key in ("prompt_tokens", "completion_tokens", "total_tokens")), "usage_missing_or_invalid")
            require(usage["prompt_tokens"] <= bound and usage["completion_tokens"] <= request.max_tokens, "usage_exceeded_reserved_token_bound")
            require(usage["total_tokens"] == usage["prompt_tokens"] + usage["completion_tokens"], "usage_total_mismatch")
            charge = priced_upper(usage["prompt_tokens"], usage["completion_tokens"], request.model, self.pricing)
            require(charge <= reservation, "usage_fee_exceeded_reservation")
            provider_result = completion.model_dump(mode="json")
            require(self.secret not in json.dumps(provider_result, ensure_ascii=False), "credential_in_provider_result_rejected")
            write(HERE / "raw" / f"{attempt['attempt_id']}-provider-result.json", provider_result)
            raw = self.captured.get(attempt["attempt_id"], {})
            require(observed_usage(raw.get("usage"), role) == usage, "raw_normalized_usage_mismatch")
            attempt["response_system_fingerprint"] = raw.get("system_fingerprint") if isinstance(raw, dict) else None
            require_judge_fingerprint(role, raw, self.auth)
            attempt.update(status="response_received", model_returned=completion.model, finish_reason=completion.finish_reason,
                           usage=usage, raw_usage=raw.get("usage") if isinstance(raw, dict) else None,
                           response_system_fingerprint=raw.get("system_fingerprint") if isinstance(raw, dict) else None,
                           budget_charged_upper_cny=money(charge), budget_basis="actual_usage_peak_all_input_cache_miss_upper_not_account_charge",
                           known_usage_peak_all_miss_upper_cny=money(charge),
                           provider_result_ref=f"raw/{attempt['attempt_id']}-provider-result.json")
            succeeded = True
            return value
        except AIClientError as exc:
            attempt.update(status="provider_failed", failure_category=exc.category.value)
            raise StopRound("provider_failed_" + exc.category.value) from exc
        except BaseException as exc:
            attempt.update(status="interrupted" if isinstance(exc, (KeyboardInterrupt, asyncio.CancelledError)) else "invalid_or_failed", failure_type=type(exc).__name__)
            if isinstance(exc, StopRound):
                attempt["failure_code"] = str(exc)
            raise
        finally:
            raw = self.captured.get(attempt["attempt_id"], {})
            raw_usage = raw.get("usage") if isinstance(raw, dict) else None
            if isinstance(raw_usage, dict):
                attempt["raw_usage"] = raw_usage
                observed = observed_usage(raw_usage, role)
                if observed is not None:
                    attempt.setdefault("usage", observed)
                    attempt["usage_record_status"] = "raw_usage_retained_even_if_structure_failed"
            if isinstance(raw, dict):
                attempt["response_identity"] = {key: raw.get(key) for key in ("id", "model", "status", "created_at", "system_fingerprint")}
                attempt["system_fingerprint_status"] = "reported" if raw.get("system_fingerprint") else "not_reported_unknown"
            if "usage" not in attempt:
                attempt["usage_record_status"] = "unknown_usage_full_reservation_retained"
            attempt["latency_ms"] = max(0, round((perf_counter() - started) * 1000))
            attempt["finished_at"] = now()
            if not succeeded:
                attempt["budget_basis"] = "full_reservation_retained_on_failure"
            self.save()
            print(json.dumps({"role": role, "input_id": input_id, "status": attempt["status"], "attempts": self.ledger["provider_attempts"], "spent_or_held_upper_cny": self.ledger["conservative_spend_or_held_upper_cny"]}, ensure_ascii=True), flush=True)
            self.active, self.expected_payload = None, None


async def execute(auth: dict, params: dict, pricing: dict, prepared_requests: dict) -> dict:
    require(auth.get("authorized") is True, "explicit_new_round_authorization_required")
    round_ = Round(auth, params, pricing)
    round_.start_exclusive()
    try:
        # 只有显式execute进入本行后才读取已有配置中的key；不打印settings或任何凭证。
        from app.core.config import AISettings
        settings = AISettings()
        require(settings.deepseek_api_key is not None, "existing_api_key_not_configured")
        round_.secret = settings.deepseek_api_key.get_secret_value()
        require(bool(round_.secret), "existing_api_key_empty")
        context = new_context()
        write(HERE / "fixed-context.json", context.to_storage())
        limits = httpx.Limits(max_connections=1, max_keepalive_connections=1)
        async with httpx.AsyncClient(
            transport=httpx.AsyncHTTPTransport(retries=0), limits=limits, follow_redirects=False,
            event_hooks={"request": [round_.capture_request], "response": [round_.capture_response]},
        ) as http:
            provider = DeepSeekProvider(
                http, api_key=settings.deepseek_api_key, base_url="https://api.deepseek.com",
                connect_timeout_seconds=5, request_timeout_seconds=60,
            )
            client = ai_client(provider, params)
            require(round_.ledger["calibration_passed"] and round_.ledger["calibration_reused"], "preflight_pro_calibration_required")
            agent = review_agent(client, params)
            for case_id in CASE_IDS:
                input_data = read(PREP / f"agent-input-templates/{case_id}-input.json")
                write(HERE / "inputs" / f"{case_id}-under-test-input.json", input_data)
                request = prepared_requests[case_id]
                execution = await round_.invoke("under_test", case_id, request, lambda: agent.run(context, input_data))
                raw_draft = json.loads(execution.completion.content)
                artifact_id = f"S08-{case_id}-candidate-v4"
                candidate_envelope = {
                    "case_id": case_id, "artifact_id": artifact_id, "text_version": "4.0", "response": raw_draft,
                    "prompt_version": "practice-review-r4", "request_version": "practice-review-responses-schema-r1", "schema_version": "practice-review/1.0",
                    "provider": "deepseek", "model_id": "deepseek-flash",
                    "raw_response_ref": round_.ledger["attempts"][-1]["raw_response_ref"],
                }
                write(HERE / "candidates" / f"{case_id}-response.json", candidate_envelope)
                judge_input = read(PREP / f"judge-input-templates/{case_id}-input.json")
                # 只填raw draft；被测型号/provider/usage/attempt身份均不进入J1材料。
                judge_input["data"]["candidate_feedback"] = json.dumps(raw_draft, ensure_ascii=False, indent=2)
                write(HERE / "judges" / f"{case_id}-input.json", judge_input)
                request = judge_request(judge_input, "judge_formal", params)
                completion = await round_.invoke("judge_formal", case_id, request, lambda: client.complete(request))
                judge_response = json.loads(completion.content)
                write(HERE / "judges" / f"{case_id}-response.json", {
                    "case_id": case_id, "candidate_artifact_id": artifact_id,
                    "candidate_text_version": "4.0", "response": judge_response,
                    "provider": "deepseek", "model_id": "deepseek-v4-pro",
                    "raw_response_ref": round_.ledger["attempts"][-1]["raw_response_ref"],
                })
                validation = validate_feedback(judge_input, judge_response)
                write(HERE / "validations" / f"{case_id}-judge.json", validation)
                round_.ledger["attempts"][-1]["validation_ref"] = f"validations/{case_id}-judge.json"
                round_.ledger["attempts"][-1]["evaluation_status"] = validation["status"]
                round_.save()
                require(validation.get("structure_binding_and_quotes_valid"), "formal_judge_invalid_" + case_id)
                require(judge_response["status"] == "scored", "formal_judge_unresolved_" + case_id)
                round_.ledger["completed_case_ids"].append(case_id)
                round_.save()
            summary = summarize(HERE / "candidates", HERE / "judges")
            write(HERE / "rule-summary.json", summary)
            passed = bool(summary.get("all_rule_gates_pass")) and round_.ledger["calibration_passed"] and len(round_.ledger["completed_case_ids"]) == 16
            round_.ledger.update(status="completed_quality_passed" if passed else "completed_quality_not_passed", S08_fixed_case_quality_passed=passed, rule_summary_ref="rule-summary.json")
    except BaseException as exc:
        if round_.ledger["attempts"] and not (isinstance(exc, StopRound) and str(exc) in {"currency_hard_cap_next_reservation_rejected_before_POST", "role_or_total_call_limit_reached"}):
            last = round_.ledger["attempts"][-1]
            last["budget_charged_upper_cny"] = last["reservation_upper_cny"]
            last["budget_basis"] = "full_reservation_retained_when_round_stopped_after_response_or_failure"
        round_.ledger.update(status="stopped", stop_error_type=type(exc).__name__)
        if isinstance(exc, StopRound):
            round_.ledger["stop_code"] = str(exc)
        round_.ledger["S08_fixed_case_quality_passed"] = False
    finally:
        round_.ledger["finished_at"] = now()
        round_.ledger["total_prompt_tokens_recorded"] = sum(row.get("usage", {}).get("prompt_tokens", 0) for row in round_.ledger["attempts"])
        round_.ledger["total_completion_tokens_recorded"] = sum(row.get("usage", {}).get("completion_tokens", 0) for row in round_.ledger["attempts"])
        round_.save()
    return round_.ledger


def ledger_brief(ledger: dict) -> dict:
    fields = ("evaluation_id", "status", "provider_attempts", "role_usage", "calibration_passed", "completed_case_ids", "conservative_spend_or_held_upper_cny", "remaining_hard_cap_upper_cny", "S08_fixed_case_quality_passed", "stop_error_type", "stop_code")
    return {key: ledger[key] for key in fields if key in ledger}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--ledger", action="store_true", help="只读已存在账本摘要，不读取key或发请求")
    args = parser.parse_args()
    try:
        if args.ledger:
            require(not args.execute, "ledger_mode_cannot_execute")
            print(json.dumps(ledger_brief(read(HERE / "ledger.json")), ensure_ascii=True, indent=2))
            return 0
        auth, params, pricing, requests, report = preflight()
        if not (HERE / "preflight.json").exists():
            write(HERE / "preflight.json", report)
        if not args.execute:
            print(json.dumps(report, ensure_ascii=True, indent=2))
            return 0
        require(auth.get("authorized") is True, "explicit_new_round_authorization_required")
        require(not report["existing_ledger"], "existing_ledger_requires_read_only_recovery_no_blind_rerun")
        require(read(HERE / "local-checks.json")["status"] == "passed", "offline_runner_checks_required_before_execute")
        ledger = asyncio.run(execute(auth, params, pricing, requests))
        print(json.dumps(ledger_brief(ledger), ensure_ascii=True, indent=2))
        return 0 if ledger["status"].startswith("completed_") else 1
    except BaseException as exc:
        safe = {"status": "runner_stopped", "error_type": type(exc).__name__, "secret_value_printed": False}
        if isinstance(exc, StopRound):
            safe["code"] = str(exc)
        print(json.dumps(safe, ensure_ascii=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

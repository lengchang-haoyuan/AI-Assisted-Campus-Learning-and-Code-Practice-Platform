"""整轮MockTransport控制夹具，只验证角色/协议/绑定，不是实际模型质量。"""

from contextlib import redirect_stdout
from copy import deepcopy
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import run_evaluation as runner
from audit_results import audit
import httpx
from pydantic import SecretStr


class RoleSwapRoundTests(unittest.IsolatedAsyncioTestCase):
    async def test_full_synthetic_round_binds_pro_review_flash_judge_and_audit_rejects_forged_model(self):
        auth, params, pricing, requests, _ = runner.preflight()
        original = runner.HERE
        cases = runner.read(original / "frozen-reference-contract.json")["cases"]
        calls = []
        marker = "合成控制夹具，中文🚀与反斜杠\\，不是模型质量证据"
        def candidate(case):
            issues = {row["criterion_id"]: row["issue_type"] for row in case["reference_issues"]}
            code = case["student_code"] or ""
            quote = next((line for line in code.splitlines() if line.strip()), None)
            criteria = []
            for cid, verdict in case["reference_criteria"].items():
                criteria.append({"criterion_id": cid, "verdict": verdict,
                                 "issue_type": issues.get(cid) if verdict == "fail" else None,
                                 "evidence_span": quote if verdict == "fail" else None, "reason": marker,
                                 "suggested_self_test": marker if verdict == "fail" else None,
                                 "next_action": marker if verdict in {"fail", "unknown"} else None})
            return {"summary": marker, "overall": case["reference_label"], "criteria": criteria}
        def handler(request):
            body = json.loads(request.content)
            index = len(calls)
            calls.append(str(request.url))
            case = cases[index // 2]
            if index % 2 == 0:
                self.assertEqual(body["model"], "deepseek-v4-pro")
                self.assertTrue(str(request.url).endswith("/responses"))
                return httpx.Response(200, json={"id": "synthetic-" + case["case_id"], "model": body["model"], "status": "completed",
                    "output": [{"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": json.dumps(candidate(case), ensure_ascii=False)}]}],
                    "usage": {"input_tokens": 100, "output_tokens": 100, "total_tokens": 200}})
            self.assertEqual(body["model"], "deepseek-flash")
            self.assertTrue(str(request.url).endswith("/chat/completions"))
            response = {"case_id": case["case_id"], "status": "scored", "criterion_evidence": [
                {"criterion_id": cid, "evidence_valid": True, "quote": marker, "reason": marker}
                for cid in case["reference_criteria"]], "actionability_score": 3, "unsupported_claim": False, "reason": marker}
            return httpx.Response(200, json={"model": body["model"], "system_fingerprint": auth["judge_calibration_system_fingerprint"],
                "choices": [{"message": {"content": json.dumps(response, ensure_ascii=False)}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 100, "completion_tokens": 100, "total_tokens": 200}})
        local_auth = deepcopy(auth)
        local_auth["authorized"] = True
        local_auth["authorization_source"] = "unit-only synthetic authorization, never real Provider"
        with TemporaryDirectory(prefix=".unit-only-role-swap-", dir=original) as directory:
            target = Path(directory).resolve()
            for name in ("parameters.json", "wire-output-schema.json", "production-contract-binding.json", "review-draft-schema.json", "frozen-reference-contract.json", "calibration-reuse.json"):
                (target / name).write_bytes((original / name).read_bytes())
            with patch.object(runner, "HERE", target):
                runner.write(target / "authorization.json", local_auth)
                runner.write(target / "pricing-basis.json", pricing)
                with patch("app.core.config.AISettings", return_value=SimpleNamespace(deepseek_api_key=SecretStr("synthetic-unit-role-key"))), patch.object(runner.httpx, "AsyncHTTPTransport", return_value=httpx.MockTransport(handler)), redirect_stdout(io.StringIO()):
                    ledger = await runner.execute(local_auth, params, pricing, requests)
                self.assertEqual(ledger["status"], "completed_quality_passed")
                self.assertEqual(ledger["provider_attempts"], 32)
                self.assertEqual(ledger["role_usage"], {"under_test": 16, "judge_calibration": 0, "judge_formal": 16})
                result = audit(target)
                self.assertEqual(result["audit_status"], "passed")
                self.assertEqual(result["new_calls"], 32)
                path = target / "candidates/Q01-response.json"
                envelope = runner.read(path)
                self.assertEqual(envelope["model_id"], "deepseek-v4-pro")
                envelope["model_id"] = "deepseek-flash"
                runner.write(path, envelope)
                with self.assertRaisesRegex(AssertionError, "envelope_role_model_identity"):
                    audit(target)
        self.assertEqual(len(calls), 32)
        self.assertFalse(target.exists())
        self.assertFalse((original / "ledger.json").exists())


    async def check_judge_failure(self, failure):
        auth, params, pricing, requests, _ = runner.preflight()
        original = runner.HERE
        draft = runner.read(original.parent / "20261022-flash-pro-r1/candidates/Q01-response.json")["response"]
        calls = []
        def handler(request):
            body = json.loads(request.content)
            calls.append(body["model"])
            if len(calls) == 1:
                return httpx.Response(200, json={"model": "deepseek-v4-pro", "status": "completed",
                    "output": [{"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": json.dumps(draft, ensure_ascii=False)}]}],
                    "usage": {"input_tokens": 100, "output_tokens": 100, "total_tokens": 200}})
            return httpx.Response(200, json={"model": "deepseek-flash", "system_fingerprint": ("changed-unit-service" if failure == "fingerprint" else auth["judge_calibration_system_fingerprint"]),
                "choices": [{"message": {"content": "synthetic-invalid-json"}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 100, "completion_tokens": 100, "total_tokens": 200}})
        local_auth = deepcopy(auth)
        local_auth["authorized"] = True
        with TemporaryDirectory(prefix=".unit-only-judge-failure-", dir=original) as directory:
            target = Path(directory).resolve()
            for name in ("parameters.json", "wire-output-schema.json", "production-contract-binding.json", "review-draft-schema.json", "frozen-reference-contract.json", "calibration-reuse.json"):
                (target / name).write_bytes((original / name).read_bytes())
            with patch.object(runner, "HERE", target):
                runner.write(target / "authorization.json", local_auth)
                runner.write(target / "pricing-basis.json", pricing)
                with patch("app.core.config.AISettings", return_value=SimpleNamespace(deepseek_api_key=SecretStr("synthetic-unit-role-key"))), patch.object(runner.httpx, "AsyncHTTPTransport", return_value=httpx.MockTransport(handler)), redirect_stdout(io.StringIO()):
                    ledger = await runner.execute(local_auth, params, pricing, requests)
                self.assertEqual(ledger["status"], "stopped")
                self.assertEqual(ledger["stop_error_type"], "StopRound" if failure == "fingerprint" else "JSONDecodeError")
                if failure == "fingerprint":
                    self.assertFalse(ledger["calibration_passed"])
                    self.assertFalse(ledger["calibration_reused"])
                self.assertEqual(ledger["provider_attempts"], 2)
                self.assertNotIn("evidence_finalize_error_type", ledger)
                self.assertEqual(runner.read(target / "case-status.json")["counts"]["not_run"], 15)
                self.assertIsNone(runner.read(target / "rule-summary.json")["quality_metrics"])
                self.assertEqual(audit(target)["audit_status"], "passed")
        self.assertEqual(calls, ["deepseek-v4-pro", "deepseek-flash"])
        self.assertFalse((original / "ledger.json").exists())

    async def test_invalid_judge_json_and_changed_service_stop_with_auditable_partial_round(self):
        for failure in ("json", "fingerprint"):
            with self.subTest(failure=failure):
                await self.check_judge_failure(failure)


if __name__ == "__main__":
    unittest.main()

"""核对本轮原始结果与账本、确定性重算费用和评分；无模型或数据库调用。"""

from collections import Counter
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path

from score_results_r2 import summarize

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    ledger = read(HERE / "ledger.json")
    auth = read(HERE / "authorization.json")
    pricing = read(HERE / "pricing-basis.json")
    checks = []

    def check(name, condition):
        checks.append({"name": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)

    check("finished_round_not_running", ledger["status"] != "running")
    counts = Counter(row["role"] for row in ledger["attempts"])
    check("attempt_and_role_counts", len(ledger["attempts"]) == ledger["provider_attempts"] <= 32 and all(counts[role] == ledger["role_usage"][role] <= limit for role, limit in auth["role_limits"].items()))
    check("no_new_calibration_reuse_preserved", counts["judge_calibration"] == 0 and ledger["calibration_reused"] and ledger["calibration_passed"])
    check("no_retries", ledger["max_retries"] == ledger["transport_retries"] == 0)
    role_cost = Counter()
    role_held = Counter()
    token_counts = Counter()
    fees = Decimal(0)
    known_usage_fees = Decimal(0)
    for attempt in ledger["attempts"]:
        aid = attempt["attempt_id"]
        if attempt.get("status") != "response_received":
            check(aid + "_failed_attempt_retains_reservation", attempt["budget_charged_upper_cny"] == attempt["reservation_upper_cny"])
            fees += Decimal(attempt["budget_charged_upper_cny"])
            continue
        request = read(HERE / attempt["raw_request_ref"])
        response = read(HERE / attempt["raw_response_ref"])
        provider_result = read(HERE / attempt["provider_result_ref"])
        check(aid + "_one_http_200_stop", attempt["http_request_events"] == 1 and attempt["http_status"] == 200 and response["choices"][0]["finish_reason"] == "stop")
        check(aid + "_identity_and_caps", request["model"] == response["model"] == attempt["model_requested"] == provider_result["model"] and request["max_tokens"] == attempt["output_cap"])
        check(aid + "_parameters_and_no_headers", request["temperature"] == 0 and request["stream"] is False and request["thinking"] == {"type": "disabled"} and request["response_format"] == {"type": "json_object"} and "headers" not in request)
        usage = response["usage"]
        check(aid + "_raw_usage_matches_ledger_and_provider", all(usage[key] == attempt["usage"][key] == provider_result["usage"][key] for key in ("prompt_tokens", "completion_tokens", "total_tokens")))
        bound = len(json.dumps(request["messages"], ensure_ascii=False, separators=(",", ":")).encode("utf-8")) + 512
        prices = pricing["models"][request["model"]]["peak"]
        reservation = (Decimal(bound) * Decimal(prices["input_cache_miss"]) + Decimal(request["max_tokens"]) * Decimal(prices["output"])) / 1000000
        fee = (Decimal(usage["prompt_tokens"]) * Decimal(prices["input_cache_miss"]) + Decimal(usage["completion_tokens"]) * Decimal(prices["output"])) / 1000000
        charged_or_held = Decimal(attempt["budget_charged_upper_cny"])
        retained_on_stop = attempt["budget_basis"].startswith("full_reservation_retained")
        check(aid + "_reservation_and_actual_usage_upper", bound == attempt["input_upper_tokens"] and reservation == Decimal(attempt["reservation_upper_cny"]) and fee == Decimal(attempt["known_usage_peak_all_miss_upper_cny"]) <= reservation and charged_or_held == (reservation if retained_on_stop else fee))
        role_cost[attempt["role"]] += fee
        role_held[attempt["role"]] += charged_or_held
        known_usage_fees += fee
        fees += charged_or_held
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            token_counts[key] += usage[key]
        token_counts["cache_hit_tokens"] += usage.get("prompt_cache_hit_tokens", 0)
        token_counts["cache_miss_tokens"] += usage.get("prompt_cache_miss_tokens", 0)
        cid = attempt["input_id"]
        if attempt["role"] == "judge_formal":
            check(aid + "_same_calibrated_service", response.get("system_fingerprint") == auth["judge_calibration_system_fingerprint"])
            envelope = read(HERE / f"judges/{cid}-response.json")
            check(aid + "_judge_raw_and_saved_result", json.loads(response["choices"][0]["message"]["content"]) == envelope["response"])
            check(aid + "_judge_input_is_actual_post", json.loads(request["messages"][1]["content"]) == read(HERE / f"judges/{cid}-input.json"))
        else:
            envelope = read(HERE / f"candidates/{cid}-response.json")
            check(aid + "_candidate_raw_and_v2_binding", json.loads(response["choices"][0]["message"]["content"]) == envelope["response"] and envelope["artifact_id"] == f"S08-{cid}-candidate-v2" and envelope["text_version"] == "2.0" and envelope["prompt_version"] == "practice-review-r2")
        # Provider正常会strip输出首尾空白；不改原响应来制造逐字相等。
        check(aid + "_provider_content_preserves_normalized_body", provider_result["content"] == response["choices"][0]["message"]["content"].strip())
    check("money_total_below_hard_cap", fees == Decimal(ledger["conservative_spend_or_held_upper_cny"]) <= Decimal(auth["currency_hard_cap"]))
    check("remaining_money_matches", Decimal(ledger["remaining_hard_cap_upper_cny"]) == Decimal(auth["currency_hard_cap"]) - fees)
    check("total_tokens_match_ledger", token_counts["prompt_tokens"] == ledger["total_prompt_tokens_recorded"] and token_counts["completion_tokens"] == ledger["total_completion_tokens_recorded"])
    completed = ledger["status"].startswith("completed_")
    replay = summarize(HERE / "candidates", HERE / "judges")
    if completed:
        check("all_fixed_cases_and_roles_finished", ledger["completed_case_ids"] == [f"Q{i:02}" for i in range(1, 17)] and counts["under_test"] == counts["judge_formal"] == 16)
        check("pure_scoring_replay_exact", replay == read(HERE / "rule-summary.json"))
        check("quality_flag_matches_rules_and_calibration", ledger["S08_fixed_case_quality_passed"] == (replay["all_rule_gates_pass"] and ledger["calibration_passed"]))
    else:
        check("stopped_round_keeps_incomplete_metrics", replay["status"] == "not_completed" and replay["quality_metrics"] is None)
        if (HERE / "rule-summary.json").exists():
            check("existing_partial_summary_same", replay == read(HERE / "rule-summary.json"))
        else:
            (HERE / "rule-summary.json").write_text(json.dumps(replay, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result = {
        "checked_at": datetime.now(timezone(timedelta(hours=8))).isoformat(),
        "audit_status": "passed", "evaluation_status": ledger["status"],
        "assertions": len(checks), "checks": checks,
        "actual_calls": ledger["provider_attempts"], "role_usage": ledger["role_usage"],
        "total_usage": dict(token_counts),
        "fees": {"currency": "CNY", "conservative_spend_or_held_upper": format(fees, ".8f"), "known_usage_peak_upper": format(known_usage_fees, ".8f"), "known_usage_by_role": {key: format(value, ".8f") for key, value in role_cost.items()}, "held_or_spent_by_role": {key: format(value, ".8f") for key, value in role_held.items()}, "actual_account_charge_verified": False},
        "score_replay_status": replay["status"],
        "quality_metrics": replay.get("quality_metrics"), "rule_gates": replay.get("rule_gates"),
        "quality_passed": ledger["S08_fixed_case_quality_passed"],
        "audit_side_effects": {"model_calls": 0, "database_connections": 0, "credentials_read": False, "student_code_executed": False},
    }
    (HERE / "result-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"audit": "passed", "assertions": len(checks), "calls": ledger["provider_attempts"], "fee_upper_cny": format(fees, ".8f"), "quality_passed": result["quality_passed"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

"""新协议真实验收入口的本地守卫；MockTransport不计真实质量。"""

from contextlib import redirect_stdout
from copy import deepcopy
from decimal import Decimal
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import httpx
from pydantic import SecretStr

import run_evaluation as runner
from app.agents.base import AgentOutputValidationError
from audit_results import accounting_totals


class ResponseRunnerTests(unittest.IsolatedAsyncioTestCase):
    async def run_fixture(self, mode):
        auth, params, pricing, requests, _ = runner.preflight()
        old = runner.V2 / "S08-评价运行/20261022-flash-pro-r1/candidates/Q01-response.json"
        draft = runner.read(old)["response"]
        if mode == "invalid":
            draft["criteria"][-1]["verdict"] = None
        body = {"id": "synthetic-response", "model": "deepseek-flash", "status": "completed",
                "output": [{"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": json.dumps(draft, ensure_ascii=False)}]}],
                "usage": {"input_tokens": 100, "output_tokens": 100, "total_tokens": 200,
                          "input_tokens_details": {"cached_tokens": 20}, "output_tokens_details": {"reasoning_tokens": 0}}}
        if mode == "no_usage":
            body.pop("usage")
        transport_calls = []
        def respond(request):
            transport_calls.append(str(request.url))
            return httpx.Response(200, json=body)
        original_here = runner.HERE
        with TemporaryDirectory(prefix=".responses-runner-fixture-", dir=original_here) as directory:
            target = Path(directory).resolve()
            with patch.object(runner, "HERE", target):
                round_ = runner.Round(auth, params, pricing)
                round_.secret = "synthetic-non-secret-unit-fixture"
                round_.start_exclusive()
                async with httpx.AsyncClient(transport=httpx.MockTransport(respond), follow_redirects=False,
                         event_hooks={"request": [round_.capture_request], "response": [round_.capture_response]}) as http:
                    provider = runner.DeepSeekProvider(http, api_key=SecretStr(round_.secret), base_url="https://api.deepseek.com", connect_timeout_seconds=5, request_timeout_seconds=60)
                    client = runner.ai_client(provider, params)
                    agent = runner.review_agent(client, params)
                    data = runner.read(runner.PREP / "agent-input-templates/Q01-input.json")
                    with redirect_stdout(io.StringIO()):
                        if mode == "invalid":
                            with self.assertRaises(AgentOutputValidationError):
                                await round_.invoke("under_test", "Q01", requests["Q01"], lambda: agent.run(runner.new_context(), data))
                        elif mode == "no_usage":
                            with self.assertRaisesRegex(runner.StopRound, "usage_missing_or_invalid"):
                                await round_.invoke("under_test", "Q01", requests["Q01"], lambda: agent.run(runner.new_context(), data))
                        else:
                            result = await round_.invoke("under_test", "Q01", requests["Q01"], lambda: agent.run(runner.new_context(), data))
                            self.assertEqual(result.completion.finish_reason, "completed")
                row = deepcopy(round_.ledger["attempts"][0])
                self.assertEqual(transport_calls, ["https://api.deepseek.com/responses"])
                self.assertEqual(round_.ledger["provider_attempts"], 1)
                self.assertEqual(row["endpoint"], "/responses")
                self.assertEqual(row["system_fingerprint_status"], "not_reported_unknown")
                raw = runner.read(target / row["raw_request_ref"])
                self.assertNotIn("headers", raw)
                self.assertEqual(raw["text"]["format"]["schema"], runner.read(original_here / "wire-output-schema.json"))
                totals = accounting_totals(round_.ledger, pricing)
                if mode == "no_usage":
                    self.assertEqual(totals["unknown_usage_attempts"], [row["attempt_id"]])
                    self.assertNotIn("usage", row)
                else:
                    self.assertEqual(row["raw_usage"], body["usage"])
                    self.assertEqual(row["usage"], {"prompt_tokens": 100, "completion_tokens": 100, "total_tokens": 200})
                    self.assertEqual(totals["tokens"]["cache_hit_tokens"], 20)
                    self.assertEqual(totals["tokens"]["total_tokens"], 200)
                    self.assertEqual(totals["known_usage_peak_upper_cny"], "0.00100000")
                if mode != "success":
                    self.assertEqual(row["budget_charged_upper_cny"], row["reservation_upper_cny"])
                    self.assertFalse((target / "candidates").exists())
                else:
                    self.assertEqual(row["budget_charged_upper_cny"], "0.00100000")
        self.assertFalse(target.exists())

    async def test_native_success_actual_agent_request_matches_reserved_body(self):
        await self.run_fixture("success")

    async def test_native_invalid_retains_usage_and_full_reservation_no_retry(self):
        await self.run_fixture("invalid")

    async def test_native_unknown_usage_retains_full_reservation_no_retry(self):
        await self.run_fixture("no_usage")

    async def test_execute_requires_explicit_authorization_before_settings_or_ledger(self):
        auth, params, pricing, requests, _ = runner.preflight()
        auth["authorized"] = False
        with self.assertRaisesRegex(runner.StopRound, "explicit_new_round_authorization_required"):
            await runner.execute(auth, params, pricing, requests)
        self.assertFalse((runner.HERE / "ledger.json").exists())


if __name__ == "__main__":
    unittest.main()

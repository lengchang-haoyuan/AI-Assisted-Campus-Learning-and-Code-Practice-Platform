"""S08评价工具缺陷回归；合成夹具不计入模型质量，也不执行学生代码。"""

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from audit_results import accounting_totals
from frozen_review_schema import PracticeReviewDraft
from score_results_r3 import HERE, V2, load, summarize
from validate_judge import validate_feedback

OLD = HERE.parent / "20261023-flash-pro-r2"
PREP = V2 / "S08-评价准备/20261022-r1"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def synthetic_fixtures(work):
    candidates, judges = work / "candidates", work / "judges"
    candidates.mkdir()
    judges.mkdir()
    marker = "合成工具回归夹具，不是模型输出"
    for case in load(HERE / "frozen-reference-contract.json")["cases"]:
        cid = case["case_id"]
        issues = {row["criterion_id"]: row["issue_type"] for row in case["reference_issues"]}
        code = case["student_code"] or ""
        snippet = next((line for line in code.splitlines() if line.strip()), None)
        criteria = [{"criterion_id": key, "verdict": verdict, "issue_type": issues.get(key) if verdict == "fail" else None, "evidence_span": snippet if verdict == "fail" else None, "reason": marker, "suggested_self_test": marker if verdict == "fail" else None, "next_action": marker if verdict in {"fail", "unknown"} else None} for key, verdict in case["reference_criteria"].items()]
        draft = {"summary": marker, "overall": case["reference_label"], "criteria": criteria}
        identity = f"S08-{cid}-candidate-v2"
        save(candidates / f"{cid}-response.json", {"case_id": cid, "artifact_id": identity, "text_version": "2.0", "response": draft})
        judge_input = load(PREP / f"judge-input-templates/{cid}-input.json")
        judge_input["data"]["candidate_feedback"] = json.dumps(draft, ensure_ascii=False, indent=2)
        save(judges / f"{cid}-input.json", judge_input)
        response = {"case_id": cid, "status": "scored", "criterion_evidence": [{"criterion_id": key, "evidence_valid": True, "quote": marker, "reason": marker} for key in case["reference_criteria"]], "actionability_score": 3, "unsupported_claim": False, "reason": marker}
        save(judges / f"{cid}-response.json", {"case_id": cid, "candidate_artifact_id": identity, "candidate_text_version": "2.0", "response": response})
    return candidates, judges


class QuoteTests(unittest.TestCase):
    def test_real_Q06_decoded_quote(self):
        obj = load(OLD / "judges/Q06-input.json")
        response = load(OLD / "judges/Q06-response.json")["response"]
        self.assertTrue(validate_feedback(obj, response)["structure_binding_and_quotes_valid"])
        self.assertFalse(load(OLD / "validations/Q06-judge.json")["structure_binding_and_quotes_valid"])
        quote = response["criterion_evidence"][3]["quote"]
        self.assertNotIn(quote, obj["data"]["candidate_feedback"])
        self.assertIn(quote, json.loads(obj["data"]["candidate_feedback"])["criteria"][3]["reason"])

    def test_exact_field_quotes_preserve_escapes(self):
        obj = load(PREP / "calibration-inputs/G01-input.json")
        response = load(HERE.parent / "20261022-flash-pro-r1/calibration/G01-response.json")
        for text in ('带"双引号"的原文', "真实换行\n第二行", r"路径C:\sample\input.csv", r"字面反斜杠\n不换行"):
            with self.subTest(text=text):
                data, answer = deepcopy(obj), deepcopy(response)
                data["data"]["candidate_feedback"] = json.dumps({"summary": text, "other": "独立字段"}, ensure_ascii=False)
                answer["criterion_evidence"][0]["quote"] = text
                self.assertTrue(validate_feedback(data, answer)["structure_binding_and_quotes_valid"])

    def test_fabricated_and_spliced_quote_rejected(self):
        obj = load(PREP / "calibration-inputs/G01-input.json")
        response = load(HERE.parent / "20261022-flash-pro-r1/calibration/G01-response.json")
        obj["data"]["candidate_feedback"] = json.dumps({"a": "唯一前段甲", "b": "唯一后段乙"}, ensure_ascii=False)
        for text in ("唯一前段甲唯一后段乙", "完全不存在的引文", ""):
            with self.subTest(text=text):
                answer = deepcopy(response)
                answer["criterion_evidence"][0]["quote"] = text
                self.assertFalse(validate_feedback(obj, answer)["structure_binding_and_quotes_valid"])

    def test_no_global_backslash_replacement(self):
        obj = load(PREP / "calibration-inputs/G01-input.json")
        response = load(HERE.parent / "20261022-flash-pro-r1/calibration/G01-response.json")
        obj["data"]["candidate_feedback"] = r"未编码JSON的字面\n保持原样"
        response["criterion_evidence"][0]["quote"] = "未编码JSON的字面\n保持原样"
        self.assertFalse(validate_feedback(obj, response)["structure_binding_and_quotes_valid"])

    def test_all_three_frozen_calibrations_unchanged(self):
        expecteds = load(PREP / "calibration-expected.json")["cases"]
        for cid in ("G01", "G02", "G03"):
            with self.subTest(cid=cid):
                result = validate_feedback(load(PREP / f"calibration-inputs/{cid}-input.json"), load(HERE.parent / f"20261022-flash-pro-r1/calibration/{cid}-response.json"), next(row for row in expecteds if row["calibration_id"] == cid))
                self.assertTrue(result["calibration_pass"])


class ScoringTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory(prefix="s08-repair-unit-")
        self.addCleanup(self.temp.cleanup)
        self.candidates, self.judges = synthetic_fixtures(Path(self.temp.name))

    def change_flag(self, cid, criterion, flag):
        path = self.judges / f"{cid}-response.json"
        value = load(path)
        next(row for row in value["response"]["criterion_evidence"] if row["criterion_id"] == criterion)["evidence_valid"] = flag
        save(path, value)

    def test_positive_control(self):
        self.assertTrue(summarize(self.candidates, self.judges)["all_rule_gates_pass"])

    def test_unsupported_pass_blocks_acceptance(self):
        self.change_flag("Q01", "C04", False)
        result = summarize(self.candidates, self.judges)
        self.assertFalse(result["all_rule_gates_pass"])
        self.assertFalse(result["rule_gates"]["unsupported_definitive_claims"])
        self.assertEqual(result["quality_metrics"]["unsupported_definitive_cells"], 1)
        self.assertEqual(result["quality_metrics"]["correct_confirmations"], "4/4")
        self.assertEqual(result["quality_metrics"]["unsupported_claims"], 0)

    def test_unsupported_fail_still_blocks(self):
        self.change_flag("Q05", "C01", False)
        result = summarize(self.candidates, self.judges)
        self.assertFalse(result["all_rule_gates_pass"])
        self.assertEqual(result["quality_metrics"]["recall"], "8/9")
        self.assertEqual(result["quality_metrics"]["false_positive_rate"], "0/69")

    def test_unknown_is_not_a_definite_pass(self):
        self.change_flag("Q14", "C01", False)
        result = summarize(self.candidates, self.judges)
        self.assertTrue(result["all_rule_gates_pass"])
        self.assertEqual(result["quality_metrics"]["unknown_definitive_cells"], 0)

    def test_unresolved_pass_not_forced_zero_or_completed(self):
        self.change_flag("Q01", "C04", None)
        result = summarize(self.candidates, self.judges)
        self.assertEqual(result["status"], "not_completed")
        self.assertIsNone(result["quality_metrics"])
        self.assertEqual(result["observed_issue_cell_flags"]["unresolved_issue_cells"], 1)
        self.assertEqual(result["frozen_denominators"], {"reference_issue_cells": 9, "known_pass_cells": 69, "unknown_cells": 18})

    def test_history_replays_from_snapshot_not_live_prompt(self):
        # 生产提示词已r2；历史r1必须仍精确复现原成绩，且不覆盖原文件。
        r1 = HERE.parent / "20261022-flash-pro-r1"
        result = summarize(r1 / "candidates", r1 / "judges", run_dir=r1, legacy_method=True)
        self.assertEqual(result, load(r1 / "rule-summary.json"))
        result = summarize(OLD / "candidates", OLD / "judges", run_dir=OLD, legacy_method=True)
        self.assertEqual(result, load(OLD / "rule-summary.json"))

    def test_frozen_schema_matches_original_snapshot(self):
        self.assertEqual(PracticeReviewDraft.model_json_schema(), load(HERE / "review-draft-schema.json"))


class AccountingTests(unittest.TestCase):
    def setUp(self):
        self.pricing = load(HERE / "pricing-basis.json")
        self.row = deepcopy(load(OLD / "ledger.json")["attempts"][0])

    def test_failed_response_keeps_known_usage_and_full_hold(self):
        self.row.update(status="invalid_or_failed", budget_charged_upper_cny=self.row["reservation_upper_cny"], budget_basis="full_reservation_retained_on_failure")
        totals = accounting_totals({"attempts": [self.row]}, self.pricing)
        self.assertEqual(totals["tokens"]["total_tokens"], self.row["usage"]["total_tokens"])
        self.assertGreater(Decimal(totals["known_usage_peak_upper_cny"]), 0)
        self.assertEqual(totals["spent_or_held_upper_cny"], self.row["reservation_upper_cny"])
        self.assertEqual(totals["unknown_usage_attempts"], [])

    def test_missing_usage_stays_unknown_and_reserved(self):
        self.row.pop("usage")
        self.row.pop("raw_usage")
        self.row.update(status="provider_failed", budget_charged_upper_cny=self.row["reservation_upper_cny"], budget_basis="full_reservation_retained_on_failure")
        totals = accounting_totals({"attempts": [self.row]}, self.pricing)
        self.assertEqual(totals["unknown_usage_attempts"], [self.row["attempt_id"]])
        self.assertEqual(totals["spent_or_held_upper_cny"], self.row["reservation_upper_cny"])
        self.assertEqual(totals["known_usage_peak_upper_cny"], "0.00000000")

    def test_original_real_totals_preserved(self):
        ledger = load(OLD / "ledger.json")
        totals = accounting_totals(ledger, self.pricing)
        self.assertEqual(totals["tokens"]["total_tokens"], 37047)
        self.assertEqual(totals["known_usage_peak_upper_cny"], "0.30904500")
        self.assertEqual(totals["spent_or_held_upper_cny"], "0.40580400")

    def test_failed_missing_reservation_rejected(self):
        self.row.update(status="invalid_or_failed", budget_basis="full_reservation_retained_on_failure")
        with self.assertRaisesRegex(ValueError, "failed_attempt_reservation_mismatch"):
            accounting_totals({"attempts": [self.row]}, self.pricing)


if __name__ == "__main__":
    unittest.main()

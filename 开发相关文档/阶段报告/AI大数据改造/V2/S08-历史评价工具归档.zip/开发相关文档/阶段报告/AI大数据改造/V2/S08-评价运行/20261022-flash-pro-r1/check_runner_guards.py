"""只测本地记账/守卫；无网络、无真实凭证，临时账本不是评价结果。"""

import asyncio
from contextlib import redirect_stdout
from decimal import Decimal
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import httpx

import run_evaluation as runner


async def guard_checks() -> dict:
    auth, params, pricing, requests, report = runner.preflight()
    original_here = runner.HERE
    checks = []

    def check(name: str, condition: bool) -> None:
        checks.append({"check": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)

    require_no_production_ledger = not (original_here / "ledger.json").exists()
    check("real_round_has_not_started", require_no_production_ledger)
    with TemporaryDirectory(prefix=".runner-guard-unit-", dir=original_here) as temporary:
        temporary_path = Path(temporary).resolve()
        check("temporary_target_within_run_directory", temporary_path.parent == original_here and temporary_path.name.startswith(".runner-guard-unit-"))
        with patch.object(runner, "HERE", temporary_path):
            round_ = runner.Round(auth, params, pricing)
            round_.start_exclusive()
            round_.secret = "synthetic-unit-credential-not-a-real-key"
            request = requests["G01"]
            operation_count = 0

            async def injected_failure():
                nonlocal operation_count
                operation_count += 1
                ledger = runner.read(temporary_path / "ledger.json")
                check("attempt_counted_before_operation", ledger["provider_attempts"] == 1 and ledger["role_usage"]["judge_calibration"] == 1)
                check("money_reserved_before_operation", Decimal(ledger["conservative_spend_or_held_upper_cny"]) > 0)
                # 直接调用本地hook，不执行transport或Provider。
                local_request = httpx.Request("POST", "https://api.deepseek.com/chat/completions", json=runner.payload_for(request), headers={"Authorization": "Bearer " + round_.secret})
                await round_.capture_request(local_request)
                request_path = temporary_path / round_.active["raw_request_ref"]
                saved_body = request_path.read_text(encoding="utf-8")
                check("raw_request_excludes_headers_and_synthetic_key", "headers" not in json.loads(saved_body) and round_.secret not in saved_body)
                raise runner.StopRound("synthetic_injected_failure_no_network")

            try:
                with redirect_stdout(io.StringIO()):
                    await round_.invoke("judge_calibration", "G01", request, injected_failure)
            except runner.StopRound as exc:
                check("injected_failure_preserved", str(exc) == "synthetic_injected_failure_no_network")
            else:
                raise AssertionError("injected_failure_did_not_stop")
            ledger = runner.read(temporary_path / "ledger.json")
            check("failure_count_not_rolled_back", ledger["provider_attempts"] == ledger["role_usage"]["judge_calibration"] == 1)
            check("failure_holds_full_reservation", ledger["attempts"][0]["budget_charged_upper_cny"] == ledger["attempts"][0]["reservation_upper_cny"])
            check("failure_has_no_response_or_fake_quality", ledger["attempts"][0]["raw_response_ref"] is None and ledger["S08_fixed_case_quality_passed"] is False)
            round_.ledger["attempts"][0]["budget_charged_upper_cny"] = "2.99000000"
            round_.save()
            try:
                await round_.invoke("judge_calibration", "G02", requests["G02"], injected_failure)
            except runner.StopRound as exc:
                check("over_cap_rejected", str(exc) == "currency_hard_cap_next_reservation_rejected_before_POST")
            else:
                raise AssertionError("over_cap_not_rejected")
            check("over_cap_does_not_call_or_count", operation_count == 1 and round_.ledger["provider_attempts"] == 1)
            round_.ledger["role_usage"]["judge_calibration"] = 3
            try:
                await round_.invoke("judge_calibration", "G03", requests["G03"], injected_failure)
            except runner.StopRound as exc:
                check("role_cap_rejected_without_borrowing", str(exc) == "role_or_total_call_limit_reached")
            else:
                raise AssertionError("role_cap_not_rejected")
            try:
                round_.start_exclusive()
            except runner.StopRound as exc:
                check("existing_artifacts_block_blind_rerun", str(exc) == "existing_raw_directory_requires_read_only_recovery")
            else:
                raise AssertionError("existing_artifacts_not_rejected")
    check("temporary_ledger_removed_real_ledger_absent", not (original_here / "ledger.json").exists() and not temporary_path.exists())
    return {"status": "passed", "scope": "offline_runner_guard_unit_test_not_model_quality_or_real_provider_attempts", "assertions": len(checks), "passed": sum(item["passed"] for item in checks), "checks": checks, "network_requests": 0, "real_credentials_read": False, "database_access": False, "real_round_ledger_created": False, "temporary_fixtures_retained": False, "preflight_status": report["status"]}


if __name__ == "__main__":
    print(json.dumps(asyncio.run(guard_checks()), ensure_ascii=True, indent=2))
